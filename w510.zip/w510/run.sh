#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
export PYTHONPATH="${SCRIPT_DIR}:${PYTHONPATH}"

set -e

CKPT_DIR="${TRAIN_CKPT_PATH:-./checkpoints}"
LOG_DIR="${TRAIN_LOG_PATH:-./logs}"

# ============================================================
# v8: cat+linear pair features + no cosine LR
#
# Changes vs v7 (val AUC 0.8653, eval AUC 0.8246):
#   + pair features changed from element-wise multiply (140-dim)
#     to cat(int_vals, dense_vals) (280-dim); user_dense_proj acts
#     as the linear — learnable cross-dim interaction (F: cat-then-linear)
#   - removed cosine LR scheduler (F19: cosine hurts test AUC,
#     val +0.0012 but test -0.0015; v7 also only used 32% of decay)
#   ~ patience 8->5 for fast validation; relax once confirmed effective
# ============================================================
echo "========== v8: cat+linear pair features, no cosine LR =========="
python3 -u "${SCRIPT_DIR}/train.py" \
    --ns_tokenizer_type rankmixer \
    --user_ns_tokens 5 \
    --item_ns_tokens 2 \
    --num_queries 2 \
    --per_seq_queries 1,3,3,1 \
    --rank_mixer_mode ffn_only \
    --ns_groups_json "" \
    --emb_skip_threshold 1000000 \
    --num_workers 8 \
    --batch_size 128 \
    --grad_accum_steps 2 \
    --reinit_sparse_after_epoch 1 \
    --reinit_cardinality_threshold 0 \
    --dropout_rate 0.01 \
    --no_timestamp_features \
    --seq_max_lens "seq_a:384,seq_b:384,seq_c:768,seq_d:768" \
    --patience 5 \
    --label_smoothing 0.05 \
    --pairwise_weight 1.0 \
    --amp_dtype bf16 \
    --use_gradient_checkpointing \
    --ckpt_dir "${CKPT_DIR}" \
    --log_dir "${LOG_DIR}"

echo "========== v8 complete =========="
