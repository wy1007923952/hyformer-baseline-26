SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
export PYTHONPATH="${SCRIPT_DIR}:${PYTHONPATH}"

set -e

echo "========== EDA Start =========="
python3 -u "${SCRIPT_DIR}/eda.py"
echo "========== EDA End =========="
