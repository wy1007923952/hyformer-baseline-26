"""TAAC 2026 — 训练数据探索性分析
纯 numpy + pyarrow 实现，不依赖 PyTorch
"""

import gc
import glob
import json
import os
import datetime
from collections import defaultdict, OrderedDict

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq

SEP_LINE = "=" * 72
MAX_TS = 2_000_000
MAX_DT = 200_000


def _percentile_summary(arr, points=(0, 25, 50, 75, 90, 95, 99, 100)):
    if arr.size == 0:
        return "N/A"
    vals = np.percentile(arr, points)
    names = ["min", "p25", "p50", "p75", "p90", "p95", "p99", "max"]
    return "  ".join(f"{n}={v:.0f}" for n, v in zip(names, vals))


def _hour_summary(arr, points=(0, 25, 50, 75, 90, 95, 99, 100)):
    if arr.size == 0:
        return "N/A"
    vals = np.percentile(arr, points) / 3600.0
    names = ["min", "p25", "p50", "p75", "p90", "p95", "p99", "max"]
    return "  ".join(f"{n}={v:.1f}h" for n, v in zip(names, vals))


def _day_summary(arr, points=(0, 25, 50, 75, 90, 95, 99, 100)):
    if arr.size == 0:
        return "N/A"
    vals = np.percentile(arr, points) / 86400.0
    names = ["min", "p25", "p50", "p75", "p90", "p95", "p99", "max"]
    return "  ".join(f"{n}={v:.1f}d" for n, v in zip(names, vals))


class DataInspector:
    def __init__(self, data_dir, log_dir):
        self.data_dir = data_dir
        self.log_dir = log_dir
        self._accumulators()

    def _accumulators(self):
        self.total_rows = 0
        self.pos_hits = 0
        self.uid_set = set()
        self.iid_set = set()
        self.ts_buf = []
        self.seq_len = OrderedDict()
        self.last_delta = OrderedDict()
        self.intra_delta = OrderedDict()
        self.miss_tbl = defaultdict(lambda: [0, 0])
        self.domains = []
        self.domain_cfg = {}

    def _load_schema(self, schema_path=None):
        if schema_path is None:
            schema_path = os.path.join(self.data_dir, "schema.json")
        with open(schema_path) as f:
            raw = json.load(f)
        self.domain_cfg = raw["seq"]
        self.domains = sorted(self.domain_cfg.keys())
        for d in self.domains:
            self.seq_len[d] = []
            self.last_delta[d] = []
            self.intra_delta[d] = []

        # 解析 user_int / item_int 列名
        ui_scalar, ui_array = [], []
        for fid, vs, dim in raw["user_int"]:
            name = f"user_int_feats_{fid}"
            (ui_array if dim > 1 else ui_scalar).append(name)

        ii_scalar, ii_array = [], []
        for fid, vs, dim in raw["item_int"]:
            name = f"item_int_feats_{fid}"
            (ii_array if dim > 1 else ii_scalar).append(name)

        dense_cols = [f"user_dense_feats_{fid}" for fid, _ in raw["user_dense"]]

        self.scalar_cols = ui_scalar + ii_scalar
        self.array_cols = ui_array + ii_array + dense_cols

    def _col_ref(self, batch, col_map, name):
        idx = col_map.get(name)
        return batch.column(idx) if idx is not None else None

    def _process_seq_block(self, batch, ts_arr, col_map, domain):
        cfg = self.domain_cfg[domain]
        prefix = cfg["prefix"]
        ts_fid = cfg["ts_fid"]
        side_cols = [fid for fid, _ in cfg["features"] if fid != ts_fid]
        if not side_cols:
            return

        probe = self._col_ref(batch, col_map, f"{prefix}_{side_cols[0]}")
        if probe is None:
            return
        probe = probe.combine_chunks()  # ChunkedArray → ListArray
        offsets = probe.offsets.to_numpy()
        seg_lens = (offsets[1:] - offsets[:-1]).astype(np.int32)
        self.seq_len[domain].extend(seg_lens.tolist())

        if ts_fid is not None and ts_arr is not None:
            ts_dc = self._col_ref(batch, col_map, f"{prefix}_{ts_fid}")
            if ts_dc is not None:
                ts_dc = ts_dc.combine_chunks()  # ChunkedArray → ListArray
                ts_off = ts_dc.offsets.to_numpy()
                ts_val = ts_dc.values.to_numpy().astype(np.int64)
                self._calc_timedelta(domain, ts_arr, ts_off, ts_val)

    def _calc_timedelta(self, domain, cur_ts, ts_off, ts_val):
        B = len(cur_ts)
        dt_buf = []
        intra_buf = []
        for i in range(B):
            s, e = int(ts_off[i]), int(ts_off[i + 1])
            if e <= s:
                continue
            seq = ts_val[s:e]
            last = int(seq[-1])
            gap = int(cur_ts[i]) - last
            if 0 <= gap < 10 * 365 * 86400:
                dt_buf.append(gap)
            if len(self.intra_delta[domain]) < MAX_DT and len(seq) >= 2:
                diffs = seq[:-1] - seq[1:]  # seq[i] - seq[i+1]
                diffs = diffs[diffs > 0]
                intra_buf.extend(diffs.tolist())
        self.last_delta[domain].extend(dt_buf)
        if len(self.intra_delta[domain]) < MAX_DT:
            self.intra_delta[domain].extend(intra_buf)

    def _scan_missing(self, batch, col_map):
        B = batch.num_rows
        for cname in self.scalar_cols:
            c = self._col_ref(batch, col_map, cname)
            self.miss_tbl[cname][1] += B
            if c is None:
                self.miss_tbl[cname][0] += B
            else:
                self.miss_tbl[cname][0] += int(c.null_count)

        for cname in self.array_cols:
            c = self._col_ref(batch, col_map, cname)
            self.miss_tbl[cname][1] += B
            if c is None:
                self.miss_tbl[cname][0] += B
            elif pa.types.is_list(c.type):
                c = c.combine_chunks()  # ChunkedArray → ListArray
                offs = c.offsets.to_numpy()
                empty_cnt = int(((offs[1:] - offs[:-1]) == 0).sum())
                self.miss_tbl[cname][0] += empty_cnt

    def _scan_batch(self, batch):
        col_map = {batch.schema.field(i).name: i for i in range(batch.num_columns)}
        B = batch.num_rows
        self.total_rows += B

        # label
        lbl = self._col_ref(batch, col_map, "label_type")
        if lbl is not None:
            lbl_np = lbl.fill_null(0).to_numpy(zero_copy_only=False)
            self.pos_hits += int((lbl_np == 2).sum())

        # user/item
        uid = self._col_ref(batch, col_map, "user_id")
        if uid is not None:
            self.uid_set.update(uid.to_pylist())
        iid = self._col_ref(batch, col_map, "item_id")
        if iid is not None:
            self.iid_set.update(iid.to_pylist())

        # timestamp
        ts_col = self._col_ref(batch, col_map, "timestamp")
        ts_arr = None
        if ts_col is not None:
            ts_arr = ts_col.to_numpy(zero_copy_only=False).astype(np.int64)
            need = MAX_TS - len(self.ts_buf)
            if need > 0:
                self.ts_buf.extend(ts_arr[:need].tolist())

        # sequences
        for d in self.domains:
            self._process_seq_block(batch, ts_arr, col_map, d)

        # missing
        self._scan_missing(batch, col_map)

    def _scan_parquet_dir(self, data_dir, log, dataset_label):
        pq_files = sorted(glob.glob(os.path.join(data_dir, "*.parquet")))
        if not pq_files:
            raise FileNotFoundError(f"目录 {data_dir} 下无 parquet 文件")

        log.info(f"[{dataset_label}] 发现 {len(pq_files)} 个 parquet 文件")
        log.info(f"领域列表: {self.domains}")

        for idx, fpath in enumerate(pq_files):
            pf = pq.ParquetFile(fpath)
            for rg in range(pf.metadata.num_row_groups):
                batch = pf.read_row_group(rg)
                self._scan_batch(batch)
            gc.collect()
            log.info(f"  [{idx + 1}/{len(pq_files)}] {os.path.basename(fpath)}  累计 {self.total_rows:,} 行")

    def _save_ids(self, cache_dir):
        import logging
        log = logging.getLogger("eda")
        uid_path = os.path.join(cache_dir, "eval_user_ids.txt")
        iid_path = os.path.join(cache_dir, "eval_item_ids.txt")
        with open(uid_path, "w") as f:
            for uid in sorted(self.uid_set):
                f.write(str(uid) + "\n")
        with open(iid_path, "w") as f:
            for iid in sorted(self.iid_set):
                f.write(str(iid) + "\n")
        log.info(f"评估集 user_id 已保存 → {uid_path}  ({len(self.uid_set):,})")
        log.info(f"评估集 item_id 已保存 → {iid_path}  ({len(self.iid_set):,})")

    def _report_overlap_from_cache(self, log_dir):
        import logging
        log = logging.getLogger("eda")
        cache_dir = os.environ.get("USER_CACHE_PATH", log_dir)

        train_uid_path = os.path.join(cache_dir, "train_user_ids.txt")
        train_iid_path = os.path.join(cache_dir, "train_item_ids.txt")

        if not (os.path.exists(train_uid_path) and os.path.exists(train_iid_path)):
            log.warning(f"训练集 ID 文件不存在，跳过重合度分析")
            log.warning(f"  期望路径: {train_uid_path}")
            log.warning(f"            {train_iid_path}")
            return

        # 加载训练集 ID
        train_u = set()
        with open(train_uid_path) as f:
            for line in f:
                line = line.strip()
                if line:
                    train_u.add(int(line))
        train_i = set()
        with open(train_iid_path) as f:
            for line in f:
                line = line.strip()
                if line:
                    train_i.add(int(line))

        log.info(f"加载训练集 user_id: {len(train_u):,}，item_id: {len(train_i):,}")

        # 计算重合
        eval_u = self.uid_set
        eval_i = self.iid_set
        common_u = train_u & eval_u
        common_i = train_i & eval_i

        buf = []
        def emit(text=""):
            buf.append(text)

        emit()
        emit(SEP_LINE)
        emit("  评估集 vs 训练集 user/item 重合度")
        emit(SEP_LINE)
        emit()

        emit(f"  训练集 user_id : {len(train_u):>12,}")
        emit(f"  评估集 user_id : {len(eval_u):>12,}")
        emit(f"  重合 user_id   : {len(common_u):>12,}")
        emit(f"  覆盖率 (eval→train): {100 * len(common_u) / max(len(eval_u), 1):.2f}%")
        emit(f"  覆盖率 (train→eval): {100 * len(common_u) / max(len(train_u), 1):.2f}%")
        emit()

        emit(f"  训练集 item_id: {len(train_i):>12,}")
        emit(f"  评估集 item_id: {len(eval_i):>12,}")
        emit(f"  重合 item_id  : {len(common_i):>12,}")
        emit(f"  覆盖率 (eval→train): {100 * len(common_i) / max(len(eval_i), 1):.2f}%")
        emit(f"  覆盖率 (train→eval): {100 * len(common_i) / max(len(train_i), 1):.2f}%")

        report = "\n".join(buf)
        log.info(report)

        out_path = os.path.join(log_dir, "eda_overlap_report.txt")
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(report + "\n")
        log.info(f"重合报告已保存 → {out_path}")

    def scan(self):
        import logging
        logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(message)s", datefmt="%H:%M:%S")
        log = logging.getLogger("eda")

        log_dir = os.environ.get("TRAIN_LOG_PATH", self.log_dir)
        os.makedirs(log_dir, exist_ok=True)

        # ========== 评估集 EDA ==========
        eval_data_dir = os.environ.get("EVAL_DATA_PATH")
        if not eval_data_dir:
            raise ValueError("EVAL_DATA_PATH 环境变量未设置")

        schema_path = os.path.join(os.environ.get('MODEL_OUTPUT_PATH'), "schema.json")
        if not os.path.exists(schema_path):
            schema_path = os.path.join(eval_data_dir, "schema2.json")


        self._load_schema(schema_path)
        self._scan_parquet_dir(eval_data_dir, log, "评估集")
        self._build_report(log_dir, suffix="_eval")

        # 保存评估集 user/item id
        cache_dir = os.environ.get("USER_CACHE_PATH", log_dir)
        os.makedirs(cache_dir, exist_ok=True)
        self._save_ids(cache_dir)

        # ========== 加载训练集 ID 并计算重合度 ==========
        self._report_overlap_from_cache(log_dir)

    def _build_report(self, log_dir, suffix=""):
        import logging
        log = logging.getLogger("eda")
        buf = []

        def emit(text=""):
            buf.append(text)

        emit()
        emit(SEP_LINE)
        emit("  TAAC 2026 训练数据 EDA 报告")
        emit(SEP_LINE)

        # 1. 基本统计
        emit()
        emit("[1] 基础计数")
        emit(f"  总行数              : {self.total_rows:,}")
        emit(f"  唯一 user_id        : {len(self.uid_set):,}")
        emit(f"  唯一 item_id        : {len(self.iid_set):,}")
        pos_rate = 100.0 * self.pos_hits / max(self.total_rows, 1)
        emit(f"  正样本 (label==2)   : {self.pos_hits:,}  ({pos_rate:.3f}%)")
        emit(f"  负样本              : {self.total_rows - self.pos_hits:,}")

        # 2. 时间戳分布
        emit()
        emit("[2] 时间戳分布")
        if self.ts_buf:
            ts = np.array(self.ts_buf, dtype=np.int64)
            utc_min = datetime.datetime.utcfromtimestamp(int(ts.min())).strftime("%Y-%m-%d %H:%M")
            utc_max = datetime.datetime.utcfromtimestamp(int(ts.max())).strftime("%Y-%m-%d %H:%M")
            emit(f"  区间 (UTC)  : {utc_min}  →  {utc_max}")

            local_hr = ((ts + 8 * 3600) // 3600) % 24
            hr_cnt = np.bincount(local_hr.astype(int), minlength=24)
            emit("  小时分布 (UTC+8, 归一化至 100):")
            for h in range(24):
                bar = "#" * int(40 * hr_cnt[h] / hr_cnt.max())
                emit(f"    {h:02d}h  {hr_cnt[h]:>8,}  {bar}")

            day_ts = (ts + 8 * 3600) // 86400
            wday = (day_ts + 3) % 7
            wd_cnt = np.bincount(wday.astype(int), minlength=7)
            wd_lbl = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
            emit("  星期分布 (UTC+8):")
            for w in range(7):
                bar = "#" * int(40 * wd_cnt[w] / wd_cnt.max())
                emit(f"    {wd_lbl[w]}  {wd_cnt[w]:>8,}  {bar}")

        # 3. 序列长度
        emit()
        emit("[3] 各领域序列长度")
        hdr = f"  {'领域':<8}  {'样本数':>10}  {'均值':>7}  {'min':>6}  {'p25':>6}  {'p50':>6}  {'p90':>6}  {'p99':>6}  {'最大':>6}  {'空率%':>7}"
        emit(hdr)
        for d in self.domains:
            arr = np.array(self.seq_len[d], dtype=np.int32)
            if arr.size == 0:
                emit(f"  {d:<8}  无数据")
                continue
            empty_ratio = 100.0 * (arr == 0).sum() / arr.size
            p = np.percentile(arr, [25, 50, 90, 99])
            emit(f"  {d:<8}  {arr.size:>10,}  {arr.mean():>7.1f}  {arr.min():>6.0f}  {p[0]:>6.0f}  {p[1]:>6.0f}  {p[2]:>6.0f}  {p[3]:>6.0f}  {arr.max():>6}  {empty_ratio:>6.1f}%")

        # 4. 末次行为距当前的时间差
        emit()
        emit("[4] 序列末次事件 → 当前时间戳 间隔")
        emit("    (用户多久以前产生最后一次交互)")
        for d in self.domains:
            arr = np.array(self.last_delta[d], dtype=np.float64)
            if arr.size == 0:
                emit(f"  {d}: 无数据")
                continue
            emit(f"  {d}  (n={arr.size:,})")
            emit(f"    秒: {_percentile_summary(arr)}  mean={arr.mean():.0f}")
            emit(f"    小时: {_hour_summary(arr)}  mean={arr.mean()/3600.0:.1f}h")
            emit(f"    天: {_day_summary(arr)}  mean={arr.mean()/86400.0:.1f}d")

        # 5. 序列内部相邻事件时间差
        emit()
        emit("[5] 序列内相邻事件时间差 (已采样)")
        for d in self.domains:
            arr = np.array(self.intra_delta[d], dtype=np.float64)
            if arr.size == 0:
                emit(f"  {d}: 无数据")
                continue
            emit(f"  {d}  (n={arr.size:,})")
            emit(f"    秒: {_percentile_summary(arr)}  mean={arr.mean():.0f}")
            emit(f"    小时: {_hour_summary(arr)}  mean={arr.mean()/3600.0:.1f}h")
            emit(f"    天: {_day_summary(arr)}  mean={arr.mean()/86400.0:.1f}d")

        # 6. 特征缺失率
        emit()
        emit("[6] 特征缺失 / 空列表率")
        rankings = sorted(self.miss_tbl.items(), key=lambda kv: -kv[1][0] / max(kv[1][1], 1))
        emitted = False
        emit("  (仅显示缺失率 > 1% 的特征；标量=null 计数，列表=空列表计数)")
        for cname, (miss, total) in rankings:
            rate = 100.0 * miss / max(total, 1)
            if rate >= 1.0:
                emit(f"  {cname:<45s}  {rate:>6.1f}%  ({miss:,}/{total:,})")
                emitted = True
        if not emitted:
            emit("  所有特征缺失率均 < 1%，覆盖率良好")

        emit()
        emit(SEP_LINE)
        report = "\n".join(buf)
        log.info(report)

        out_path = os.path.join(log_dir, f"eda{suffix}_report.txt")
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(report + "\n")
        log.info(f"报告已保存 → {out_path}")


def main():
    inspector = DataInspector(
        data_dir=os.environ.get("EVAL_DATA_PATH", "."),
        log_dir=os.environ.get("TRAIN_LOG_PATH", "./logs"),
    )
    inspector.scan()


if __name__ == "__main__":
    main()
