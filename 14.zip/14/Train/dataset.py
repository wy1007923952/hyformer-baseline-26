"""PCVR Parquet dataset module (performance-tuned).

Reads raw multi-column Parquet directly and obtains feature metadata from
``schema.json``.

Optimizations:
- Pre-allocated numpy buffers to eliminate ``np.zeros`` + ``np.stack`` overhead.
- Fused padding loop over sequence domains that writes directly into a 3D buffer.
- Pre-computed column-index lookup to avoid per-row string lookups.
- ``file_system`` tensor-sharing strategy to work around ``/dev/shm`` exhaustion
  when using many DataLoader workers.
"""

import os
import logging
import random
import json
import gc

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
import torch
import torch.multiprocessing
from torch.utils.data import IterableDataset, DataLoader
from typing import Any, Dict, Iterator, List, Optional, Tuple

# numpy.typing is available since numpy >= 1.20; on older numpy fall back to a
# no-op shim so that forward-referenced annotations like ``npt.NDArray[np.int64]``
# keep working as plain strings without raising at import time.
try:
    import numpy.typing as npt  # noqa: F401
except ImportError:  # pragma: no cover
    class _NptFallback:  # type: ignore[no-redef]
        NDArray = Any

    npt = _NptFallback()  # type: ignore[assignment]


# ─────────────────────────── Feature Schema ──────────────────────────────────


class FeatureSchema:
    """Records ``(feature_id, offset, length)`` for each feature so downstream
    code can locate the segment of the flattened tensor that belongs to a
    specific feature id.

    For int features:
      - int_value: length = 1
      - int_array: length = array length
      - int_array_and_float_array: int part length
    For dense features:
      - float_value: length = 1
      - float_array: length = array length
      - int_array_and_float_array: float part length
    """

    def __init__(self) -> None:
        # Ordered list of (feature_id, offset, length).
        self.entries: List[Tuple[int, int, int]] = []
        self.total_dim: int = 0
        # Quick lookup from fid to its (offset, length).
        self._fid_to_entry: Dict[int, Tuple[int, int]] = {}

    def add(self, feature_id: int, length: int) -> None:
        """Append a feature to the schema."""
        offset = self.total_dim
        self.entries.append((feature_id, offset, length))
        self._fid_to_entry[feature_id] = (offset, length)
        self.total_dim += length

    def get_offset_length(self, feature_id: int) -> Tuple[int, int]:
        """Get ``(offset, length)`` for a feature_id."""
        return self._fid_to_entry[feature_id]

    @property
    def feature_ids(self) -> List[int]:
        """Return all feature_ids in their insertion order."""
        return [fid for fid, _, _ in self.entries]

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to a plain dict (for JSON dumping)."""
        return {
            'entries': self.entries,
            'total_dim': self.total_dim,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> 'FeatureSchema':
        """Reconstruct a :class:`FeatureSchema` from its dict form."""
        schema = cls()
        for fid, offset, length in d['entries']:
            schema.entries.append((fid, offset, length))
            schema._fid_to_entry[fid] = (offset, length)
        schema.total_dim = d['total_dim']
        return schema

    def __repr__(self) -> str:
        lines = [f"FeatureSchema(total_dim={self.total_dim}, features=["]
        for fid, offset, length in self.entries:
            lines.append(f"  fid={fid}: offset={offset}, length={length}")
        lines.append("])")
        return "\n".join(lines)

# Use filesystem-based tensor sharing (instead of /dev/shm) to avoid running
# out of shared memory when many DataLoader workers are active.
torch.multiprocessing.set_sharing_strategy('file_system')

# Time-delta bucket boundaries (64 edges -> 65 buckets: 0=padding, 1..64).
BUCKET_BOUNDARIES = np.array([
    5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60,
    120, 180, 240, 300, 360, 420, 480, 540, 600,
    900, 1200, 1500, 1800, 2100, 2400, 2700, 3000, 3300, 3600,
    5400, 7200, 9000, 10800, 12600, 14400, 16200, 18000, 19800, 21600,
    32400, 43200, 54000, 64800, 75600, 86400,
    172800, 259200, 345600, 432000, 518400, 604800,
    1123200, 1641600, 2160000, 2592000,
    4320000, 6048000, 7776000,
    11664000, 15552000,
    31536000,
], dtype=np.int64)

# Total number of time-bucket embedding slots (= number of boundaries + 1, with
# padding=0 included).
#
# This constant is uniquely determined by the length of BUCKET_BOUNDARIES; on
# the model side, ``nn.Embedding(num_embeddings=NUM_TIME_BUCKETS)`` must match
# this value exactly, otherwise an IndexError may be raised at runtime.
#
# That is why ``train.py`` / ``infer.py`` only expose the boolean flag
# ``--use_time_buckets`` and derive the concrete bucket count from here.
NUM_TIME_BUCKETS = len(BUCKET_BOUNDARIES) + 1


class PCVRParquetDataset(IterableDataset):
    """PCVR dataset that reads raw multi-column Parquet directly.

    - int features: scalar or list (multi-hot); values <= 0 are mapped to 0 (padding).
    - dense features: ``list<float>``, variable-length padded up to ``max_dim``.
    - sequence features: ``list<int64>``, grouped by domain; includes side-info
      columns and an optional timestamp column (used for time-bucketing).
    - label: mapped from ``label_type == 2``.
    """

    def __init__(
        self,
        parquet_path: str,
        schema_path: str,
        batch_size: int = 256,
        seq_max_lens: Optional[Dict[str, int]] = None,
        shuffle: bool = True,
        buffer_batches: int = 20,
        row_group_range: Optional[Tuple[int, int]] = None,
        clip_vocab: bool = True,
        is_training: bool = True,
        scale_dense = True # !
    ) -> None:
        """
        Args:
            parquet_path: either a directory containing ``*.parquet`` files or
                a single parquet file path.
            schema_path: path of the schema JSON describing feature layouts.
            batch_size: fixed batch size used for the pre-allocated buffers.
            seq_max_lens: optional per-domain override of sequence truncation,
                e.g. ``{'seq_d': 256}``. Domains not listed fall back to the
                schema default of 256.
            shuffle: whether to shuffle within a ``buffer_batches``-sized window.
            buffer_batches: shuffle buffer size in units of batches.
            row_group_range: ``(start, end)`` slice of Row Groups; ``None`` to
                use all Row Groups.
            clip_vocab: if True, clip out-of-bound ids to 0; if False, raise.
            is_training: if True, derive ``label`` from ``label_type == 2``;
                if False, return an all-zeros label column.
        """
        super().__init__()

        # Accept either a directory or a single file path.
        if os.path.isdir(parquet_path): # '/Users/wangyang/Downloads/taac26/data_sample_1000'
            import glob
            files = sorted(glob.glob(os.path.join(parquet_path, '*.parquet'))) # ['/Users/wangyang/Downloads/taac26/data_sample_1000/demo_1000.parquet']
            if not files:
                raise FileNotFoundError(f"No .parquet files in {parquet_path}")
            self._parquet_files = files # ['/Users/wangyang/Downloads/taac26/data_sample_1000/demo_1000.parquet']
        else:
            self._parquet_files = [parquet_path]

        self.batch_size = batch_size # 16
        self.shuffle = shuffle # 训练集为 True, 验证集为 False
        self.buffer_batches = buffer_batches # 20
        self.clip_vocab = clip_vocab # True ？
        self.is_training = is_training # True # 使用默认值True，没有主动赋值
        # Out-of-bound statistics:
        #   {(group, col_idx): {'count': N, 'max': M, 'min_oob': M, 'vocab': V}}
        self._oob_stats: Dict[Tuple[str, int], Dict[str, int]] = {}

        # Build the list of Row Groups.
        self._rg_list = []
        for f in self._parquet_files:
            pf = pq.ParquetFile(f)
            for i in range(pf.metadata.num_row_groups):
                self._rg_list.append((f, i, pf.metadata.row_group(i).num_rows))
        # self._rg_list: [('/Users/wangyang/Downloads/taac26/data_sample_1000/demo_1000.parquet', 0, 1000)]

        if row_group_range is not None: # 构造训练集合验证集时分别用 row_group_range 指定各自的范围，训练集指定 row_group_range=(0, n_train_rgs)，验证集指定 row_group_range=(valid_start_rg, total_rgs)
            start, end = row_group_range
            self._rg_list = self._rg_list[start:end]

        self.num_rows = sum(r[2] for r in self._rg_list) # 1000

        # seq_max_lens: {'seq_a': 256, 'seq_b': 256, 'seq_c': 512, 'seq_d': 512}
        # Load schema.json.
        self._load_schema(schema_path, seq_max_lens or {})

        # ---- Pre-compute column index lookup ----
        pf = pq.ParquetFile(self._parquet_files[0]) # '/Users/wangyang/Downloads/taac26/data_sample_1000/demo_1000.parquet'
        schema_names = pf.schema_arrow.names
        # ['user_id', 'item_id', 'label_type', 'label_time', 'timestamp', 
        # 'user_int_feats_1', 'user_int_feats_3', ..., 'user_int_feats_108', 'user_int_feats_109', 
        # 'user_dense_feats_61', 'user_dense_feats_62', ..., 'user_dense_feats_90', 'user_dense_feats_91', 
        # 'item_int_feats_5', 'item_int_feats_6', ..., 'item_int_feats_84', 'item_int_feats_85', 
        # 'domain_a_seq_38', 'domain_a_seq_39', ..., 'domain_a_seq_45', 'domain_a_seq_46', 
        # 'domain_b_seq_67', 'domain_b_seq_68', ..., 'domain_b_seq_79', 'domain_b_seq_88', 
        # 'domain_c_seq_27', 'domain_c_seq_28', ..., 'domain_c_seq_37', 'domain_c_seq_47', 
        # 'domain_d_seq_17', 'domain_d_seq_18', ..., 'domain_d_seq_25', 'domain_d_seq_26'] # 长为 120 的列表 
        self._col_idx = {name: i for i, name in enumerate(schema_names)} # 大小为 120 的字典
        # {
        #     'user_id': 0, 'item_id': 1, 'label_type': 2, 'label_time': 3, 'timestamp': 4, 
        #     'user_int_feats_1': 5, 'user_int_feats_3': 6, ..., 'user_int_feats_108': 49, 'user_int_feats_109': 50, 
        #     'user_dense_feats_61': 51, 'user_dense_feats_62': 52, ..., 'user_dense_feats_90': 59, 'user_dense_feats_91': 60, 
        #     'item_int_feats_5': 61, 'item_int_feats_6': 62, ..., 'item_int_feats_84': 73, 'item_int_feats_85': 74, 
        #     'domain_a_seq_38': 75, 'domain_a_seq_39': 76, ..., 'domain_a_seq_45': 82, 'domain_a_seq_46': 83, 
        #     'domain_b_seq_67': 84, 'domain_b_seq_68': 85, ..., 'domain_b_seq_79': 96, 'domain_b_seq_88': 97, 
        #     'domain_c_seq_27': 98, 'domain_c_seq_28': 99, ..., 'domain_c_seq_37': 108, 'domain_c_seq_47': 109, 
        #     'domain_d_seq_17': 110, 'domain_d_seq_18': 111, ..., 'domain_d_seq_25': 118, 'domain_d_seq_26': 119
        # } 
        self._ci_2_fea_name = {v: k for k, v in self._col_idx.items()} # !
        self.scale_dense = scale_dense # !

        # ---- Pre-allocate numpy buffers ----
        B = batch_size # 16
        self._buf_user_int = np.zeros((B, self.user_int_schema.total_dim), dtype=np.int64) # torch.Size([16, 411])
        self._buf_item_int = np.zeros((B, self.item_int_schema.total_dim), dtype=np.int64) # torch.Size([16, 33])
        self._buf_user_dense = np.zeros((B, self.user_dense_schema.total_dim), dtype=np.float32) # torch.Size([16, 918])
        self._buf_seq = {}
        self._buf_seq_tb = {}
        self._buf_seq_lens = {}

        # self._seq_maxlen: {'seq_a': 256, 'seq_b': 256, 'seq_c': 512, 'seq_d': 512}
        # self.sideinfo_fids: 
        # {
        #     'seq_a': [38, 40, 41, 42, 43, 44, 45, 46], # 长为 8 的列表
        #     'seq_b': [68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 88], # 长为 13 的列表
        #     'seq_c': [28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 47], # 长为 11 的列表
        #     'seq_d': [17, 18, 19, 20, 21, 22, 23, 24, 25] # 长为 9 的列表
        # }
        for domain in self.seq_domains:
            # domain 如 'seq_a'
            max_len = self._seq_maxlen[domain] # 如 256
            n_feats = len(self.sideinfo_fids[domain]) # 如 8
            self._buf_seq[domain] = np.zeros((B, n_feats, max_len), dtype=np.int64) # 如 torch.Size([16, 8, 256])
            self._buf_seq_tb[domain] = np.zeros((B, max_len), dtype=np.int64) # 如 torch.Size([16, 256])
            self._buf_seq_lens[domain] = np.zeros(B, dtype=np.int64) # torch.Size([16,])
        # self._buf_seq:
        # {
        #     'seq_a': array([[[0, 0, 0, ..., 0, 0, 0],
        #                      ...,
        #                      [0, 0, 0, ..., 0, 0, 0]],
        #                     ...,
        #                     [[0, 0, 0, ..., 0, 0, 0],
        #                      ...,
        #                      [0, 0, 0, ..., 0, 0, 0]]]), # (16, 8, 256)
        #     'seq_b': array([[[0, 0, 0, ..., 0, 0, 0],
        #                      ...,
        #                      [0, 0, 0, ..., 0, 0, 0]],
        #                     ...,
        #                     [[0, 0, 0, ..., 0, 0, 0],
        #                      ...,
        #                      [0, 0, 0, ..., 0, 0, 0]]]), # (16, 13, 256)
        #     'seq_c': array([[[0, 0, 0, ..., 0, 0, 0],
        #                      ...,
        #                      [0, 0, 0, ..., 0, 0, 0]],
        #                     ...,
        #                     [[0, 0, 0, ..., 0, 0, 0],
        #                      ...,
        #                      [0, 0, 0, ..., 0, 0, 0]]]), # (16, 11, 512)
        #     'seq_d': array([[[0, 0, 0, ..., 0, 0, 0],
        #                      ...,
        #                      [0, 0, 0, ..., 0, 0, 0]],
        #                     ...,
        #                     [[0, 0, 0, ..., 0, 0, 0],
        #                      ...,
        #                      [0, 0, 0, ..., 0, 0, 0]]]) # (16, 9, 512)
        # }

        # self._buf_seq_tb:
        # {
        #     'seq_a': array([[0, 0, 0, ..., 0, 0, 0],
        #                     ...,
        #                     [0, 0, 0, ..., 0, 0, 0]]), # (16, 256)
        #     'seq_b': array([[0, 0, 0, ..., 0, 0, 0],
        #                     ...,
        #                     [0, 0, 0, ..., 0, 0, 0]]), # (16, 256)
        #     'seq_c': array([[0, 0, 0, ..., 0, 0, 0],
        #                     ...,
        #                     [0, 0, 0, ..., 0, 0, 0]]), # (16, 512)
        #     'seq_d': array([[0, 0, 0, ..., 0, 0, 0],
        #                     ...,
        #                     [0, 0, 0, ..., 0, 0, 0]]) # (16, 512)
        # }

        # self._buf_seq_lens:
        # {
        #     'seq_a': array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]), # (16,)
        #     'seq_b': array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]), # (16,)
        #     'seq_c': array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]), # (16,)
        #     'seq_d': array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])  # (16,)
        # }

        # ---- Pre-compute (col_idx, offset, vocab_size) plans for int columns ----
        self._user_int_plan = []  # [(col_idx, dim, offset, vocab_size), ...]
        offset = 0
        for fid, vs, dim in self._user_int_cols:
            # fid 如 1, vs 如 6, dim 如 1
            # f'user_int_feats_{fid}' 如 'user_int_feats_1'
            ci = self._col_idx.get(f'user_int_feats_{fid}') # 如 5
            self._user_int_plan.append((ci, dim, offset, vs))
            offset += dim
        # self._user_int_plan: 长为 46 的列表
        # [(5, 1, 0, 6), (6, 1, 1, 1725), (7, 1, 2, 957), 
        #  (8, 26, 3, 1167), (9, 1, 29, 101), (10, 1, 30, 3), 
        #  ...,
        #  (48, 1, 408, 4), (49, 1, 409, 8), (50, 1, 410, 8)]

        self._item_int_plan = []
        offset = 0
        for fid, vs, dim in self._item_int_cols:
            # fid 如 5, vs 如 309, dim 如 1
            # f'item_int_feats_{fid}' 如 'item_int_feats_5'
            ci = self._col_idx.get(f'item_int_feats_{fid}') # 如 61
            self._item_int_plan.append((ci, dim, offset, vs))
            offset += dim
        # self._item_int_plan: 长为 14 的列表
        # [(61, 1, 0, 309), (62, 1, 1, 912), (63, 1, 2, 2443), 
        #  (64, 1, 3, 2131), (65, 1, 4, 42), (66, 1, 5, 300), 
        #  ...,
        #  (72, 1, 30, 32), (73, 1, 31, 234), (74, 1, 32, 1084)]

        self._user_dense_plan = []
        offset = 0
        for fid, dim in self._user_dense_cols:
            # fid 如 61, dim 如 256
            # f'user_dense_feats_{fid}' 如 'user_dense_feats_61'
            ci = self._col_idx.get(f'user_dense_feats_{fid}') # 如 51
            self._user_dense_plan.append((ci, dim, offset))
            offset += dim
        # self._user_dense_plan: 长为 10 的列表
        # [(51, 256, 0), (52, 6, 256), (53, 19, 262), 
        #  (54, 26, 281), (55, 111, 307), (56, 150, 418), 
        #  (57, 320, 568), (58, 10, 888), (59, 10, 898), (60, 10, 908)]

        _count_fids = {62, 63, 64, 65, 66} # ！
        self._dense_transforms = []
        for fid, dim in self._user_dense_cols:
            if fid in _count_fids:
                self._dense_transforms.append('log1p_scale')
            else:
                self._dense_transforms.append('none')

        # Sequence column plan: {domain: ([(col_idx, feat_slot, vocab_size), ...], ts_col_idx)}
        self._seq_plan = {}
        for domain in self.seq_domains:
            # domain 如 'seq_a'
            prefix = self._seq_prefix[domain] # 如 'domain_a_seq'
            sideinfo_fids = self.sideinfo_fids[domain] # 如 [38, 40, 41, 42, 43, 44, 45, 46]
            ts_fid = self.ts_fids[domain] # 如 39
            side_plan = []
            for slot, fid in enumerate(sideinfo_fids):
                # slot 如 0, fid 如 38
                ci = self._col_idx.get(f'{prefix}_{fid}') # 如 75
                vs = self.seq_vocab_sizes[domain][fid] # 如 745286
                side_plan.append((ci, slot, vs))
            # side_plan: 长为 8 的列表
            # [(75, 0, 745286), (77, 1, 19), (78, 2, 11), 
            #  (79, 3, 1005), (80, 4, 3342), (81, 5, 12735),
            #  (82, 6, 7612), (83, 7, 18)]

            # f'{prefix}_{ts_fid}' 如 'domain_a_seq_39'
            ts_ci = self._col_idx.get(f'{prefix}_{ts_fid}') if ts_fid is not None else None # 如 76
            self._seq_plan[domain] = (side_plan, ts_ci)
        print()
        # self._seq_plan:
        # {
        #     'seq_a': ([ # 长为 8 的列表
        #         (75, 0, 745286), (77, 1, 19), (78, 2, 11), 
        #         (79, 3, 1005), (80, 4, 3342), (81, 5, 12735), 
        #         (82, 6, 7612), (83, 7, 18)
        #         ], 76
        #     ), 
        #     'seq_b': ([ # 长为 13 的列表
        #         (85, 0, 28), (86, 1, 64710562), (87, 2, 726), 
        #         (88, 3, 2669), (89, 4, 10203), (90, 5, 6761), 
        #         (91, 6, 476333), (92, 7, 31), (93, 8, 132080), 
        #         (94, 9, 166), (95, 10, 4229), (96, 11, 11387), (97, 12, 199678)
        #         ], 84
        #     ), 
        #     'seq_c': ([ # 长为 11 的列表
        #         (99, 0, 73), (100, 1, 5764358), (101, 2, 846), 
        #         (102, 3, 6805), (103, 4, 7), (104, 5, 5), 
        #         (105, 6, 1031305), (106, 7, 2896), (107, 8, 977479), 
        #         (108, 9, 9433), (109, 10, 86335515)
        #         ], 98
        #     ), 
        #     'seq_d': ([ # 长为 9 的列表
        #         (110, 0, 5), (111, 1, 966), (112, 2, 3300), 
        #         (113, 3, 10785), (114, 4, 4929), (115, 5, 404398), 
        #         (116, 6, 606041), (117, 7, 531), (118, 8, 15)
        #         ], 119
        #     )
        # }

        logging.info(
            f"PCVRParquetDataset: {self.num_rows} rows from "
            f"{len(self._parquet_files)} file(s), batch_size={batch_size}, "
            f"buffer_batches={buffer_batches}, shuffle={shuffle}")

    def _load_schema(self, schema_path: str, seq_max_lens: Dict[str, int]) -> None:
        """Populate per-group schema information from ``schema_path``."""
        with open(schema_path, 'r', encoding='utf-8') as f:
            raw = json.load(f)

        # ---- user_int: [[fid, vocab_size, dim], ...] ----
        self._user_int_cols: List[List[int]] = raw['user_int'] # 长为 46 的列表
        # [[1, 6, 1], [3, 1725, 1], [4, 957, 1], 
        #  [15, 1167, 26], [48, 101, 1], [49, 3, 1], 
        #  ...,
        #  [107, 4, 1], [108, 8, 1], [109, 8, 1]]
        self.user_int_schema: FeatureSchema = FeatureSchema()
        self.user_int_vocab_sizes: List[int] = []
        for fid, vs, dim in self._user_int_cols:
            self.user_int_schema.add(fid, dim)
            self.user_int_vocab_sizes.extend([vs] * dim) # 每个 fid 对应的 vs 重复 dim 次，拼成一个 list

        # self.user_int_schema:
        # FeatureSchema(total_dim=411, features=[
        #     fid=1: offset=0, length=1
        #     fid=3: offset=1, length=1
        #     fid=4: offset=2, length=1
        #     fid=15: offset=3, length=26
        #     fid=48: offset=29, length=1
        #     fid=49: offset=30, length=1
        #     fid=50: offset=31, length=1
        #     fid=51: offset=32, length=1
        #     ...,
        #     fid=105: offset=406, length=1
        #     fid=106: offset=407, length=1
        #     fid=107: offset=408, length=1
        #     fid=108: offset=409, length=1
        #     fid=109: offset=410, length=1
        # ])

        # self.user_int_schema.entries: 长为 46 的列表
        # [(1, 0, 1), (3, 1, 1), (4, 2, 1), 
        #  (15, 3, 26), (48, 29, 1), (49, 30, 1),
        #  ...,
        #  (107, 408, 1), (108, 409, 1), (109, 410, 1)]

        # self.user_int_schema.feature_ids: 长为 46 的列表
        # [1, 3, 4, 15, 48, 49, ..., 105, 106, 107, 108, 109]

        # self.user_int_schema._fid_to_entry: 46 个元素的字典
        # {
        #     1: (0, 1), 3: (1, 1), 4: (2, 1), 
        #     15: (3, 26), 48: (29, 1), 49: (30, 1), 
        #     ...,
        #     107: (408, 1), 108: (409, 1), 109: (410, 1)
        # }

        # self.user_int_vocab_sizes: 长为 411 的列表
        # [6, 1725, 957, 1167, 1167, 1167, ..., 4, 4, 4, 4, 4, 4, 4, 4, 8, 8]

        # ---- item_int: [[fid, vocab_size, dim], ...] ----
        self._item_int_cols: List[List[int]] = raw['item_int'] # 长为 14 的列表
        # [[5, 309, 1], [6, 912, 1], [7, 2443, 1], 
        #  [8, 2131, 1], [9, 42, 1], [10, 300, 1], 
        #  ...,
        #  [83, 32, 1], [84, 234, 1], [85, 1084, 1]]
        self.item_int_schema: FeatureSchema = FeatureSchema()
        self.item_int_vocab_sizes: List[int] = []
        for fid, vs, dim in self._item_int_cols:
            self.item_int_schema.add(fid, dim)
            self.item_int_vocab_sizes.extend([vs] * dim)

        # self.item_int_schema:
        # FeatureSchema(total_dim=33, features=[
        #     fid=5: offset=0, length=1
        #     fid=6: offset=1, length=1
        #     fid=7: offset=2, length=1
        #     fid=8: offset=3, length=1
        #     fid=9: offset=4, length=1
        #     fid=10: offset=5, length=1
        #     fid=11: offset=6, length=20
        #     fid=12: offset=26, length=1
        #     fid=13: offset=27, length=1
        #     fid=16: offset=28, length=1
        #     fid=81: offset=29, length=1
        #     fid=83: offset=30, length=1
        #     fid=84: offset=31, length=1
        #     fid=85: offset=32, length=1
        # ])

        # self.item_int_schema.entries: 长为 14 的列表
        # [(5, 0, 1), (6, 1, 1), (7, 2, 1), 
        #  (8, 3, 1), (9, 4, 1), (10, 5, 1), 
        #  ...,
        #  (83, 30, 1), (84, 31, 1), (85, 32, 1)]

        # self.item_int_schema.feature_ids: 长为 14 的列表
        # [5, 6, 7, 8, 9, 10, 11, 12, 13, 16, 81, 83, 84, 85]

        # self.item_int_schema._fid_to_entry: 14 个元素的字典
        # {
        #     5: (0, 1), 6: (1, 1), 7: (2, 1),
        #     8: (3, 1), 9: (4, 1), 10: (5, 1), 
        #     ...,
        #     83: (30, 1), 84: (31, 1), 85: (32, 1)
        # }

        # self.item_int_vocab_sizes: 长为 33 的列表
        # [309, 912, 2443, 2131, 42, 300, 21528, 21528, 21528, ..., 21528, 21528, 21528, 2443, 9, 23700, 3, 32, 234, 1084]

        # ---- user_dense: [[fid, dim], ...] ----
        self._user_dense_cols: List[List[int]] = raw['user_dense'] # 长为 10 的列表
        # [[61, 256], [62, 6], [63, 19], ..., [89, 10], [90, 10], [91, 10]]
        self.user_dense_schema: FeatureSchema = FeatureSchema()
        for fid, dim in self._user_dense_cols:
            self.user_dense_schema.add(fid, dim)

        # self.user_dense_schema:
        # FeatureSchema(total_dim=918, features=[
        #     fid=61: offset=0, length=256
        #     fid=62: offset=256, length=6
        #     fid=63: offset=262, length=19
        #     fid=64: offset=281, length=26
        #     fid=65: offset=307, length=111
        #     fid=66: offset=418, length=150
        #     fid=87: offset=568, length=320
        #     fid=89: offset=888, length=10
        #     fid=90: offset=898, length=10
        #     fid=91: offset=908, length=10
        # ])

        # self.user_dense_schema.entries: 长为 10 的列表
        # [(61, 0, 256), (62, 256, 6), (63, 262, 19), 
        #  (64, 281, 26), (65, 307, 111), (66, 418, 150),
        #  (87, 568, 320), (89, 888, 10), (90, 898, 10), (91, 908, 10)]

        # self.user_dense_schema.feature_ids: 长为 10 的列表
        # [61, 62, 63, 64, 65, 66, 87, 89, 90, 91]

        # self.user_dense_schema._fid_to_entry: 10 个元素的字典
        # {
        #     61: (0, 256), 62: (256, 6), 63: (262, 19),
        #     64: (281, 26), 65: (307, 111), 66: (418, 150), 
        #     87: (568, 320), 89: (888, 10), 90: (898, 10), 91: (908, 10)
        # }

        # ---- item_dense (empty) ---- # demo 数据 item 没有 dense 标签
        self.item_dense_schema: FeatureSchema = FeatureSchema()

        # ---- sequence domains ----
        self._seq_cfg: Dict[str, Dict[str, Any]] = raw['seq']
        # {
        #     'seq_a': {
        #         'prefix': 'domain_a_seq', 
        #         'ts_fid': 39, 
        #         'features': [[38, 745286], [39, 0], ..., [45, 7612], [46, 18]] # 长为 9 的列表
        #     }, 
        #     'seq_b': {
        #         'prefix': 'domain_b_seq', 
        #         'ts_fid': 67, 
        #         'features': [[67, 0], [68, 28], ..., [79, 11387], [88, 199678]] # 长为 10 的列表
        #     }, 
        #     'seq_c': {
        #         'prefix': 'domain_c_seq', 
        #         'ts_fid': 27, 
        #         'features': [[27, 0], [28, 73], ..., [37, 9433], [47, 86335515]] # 长为 12 的列表
        #     }, 
        #     'seq_d': {
        #         'prefix': 'domain_d_seq', 
        #         'ts_fid': 26, 
        #         'features': [[17, 5], [18, 966], ..., [25, 15], [26, 0]] # 长为 10 的列表
        #     }
        # }

        self.seq_domains: List[str] = sorted(self._seq_cfg.keys()) # ['seq_a', 'seq_b', 'seq_c', 'seq_d']
        self.seq_feature_ids: Dict[str, List[int]] = {}
        self.seq_vocab_sizes: Dict[str, Dict[int, int]] = {}
        self.seq_domain_vocab_sizes: Dict[str, List[int]] = {}
        self.ts_fids: Dict[str, Optional[int]] = {}
        self.sideinfo_fids: Dict[str, List[int]] = {}
        self._seq_prefix: Dict[str, str] = {}
        self._seq_maxlen: Dict[str, int] = {}

        for domain in self.seq_domains: # ['seq_a', 'seq_b', 'seq_c', 'seq_d']
            # domain 如 'seq_a'
            cfg = self._seq_cfg[domain]
            # cfg 如
            # {
            #     'prefix': 'domain_a_seq', 
            #     'ts_fid': 39, 
            #     'features': 'features': [[38, 745286], [39, 0], ..., [45, 7612], [46, 18]] # 长为 9 的列表
            # }
            self._seq_prefix[domain] = cfg['prefix'] # 如 'domain_a_seq'
            ts_fid = cfg['ts_fid'] # 如 39
            self.ts_fids[domain] = ts_fid

            all_fids = [fid for fid, vs in cfg['features']] # 如 [38, 39, 40, 41, 42, 43, 44, 45, 46] # 长为 9 的列表
            self.seq_feature_ids[domain] = all_fids
            self.seq_vocab_sizes[domain] = {fid: vs for fid, vs in cfg['features']} # 如 {38: 745286, 39: 0, 40: 19, 41: 11, 42: 1005, 43: 3342, 44: 12735, 45: 7612, 46: 18} # 大小为 9 的 字典

            sideinfo = [fid for fid in all_fids if fid != ts_fid] # 从 all_fids 中剔除掉 ts_fid
            self.sideinfo_fids[domain] = sideinfo # 如 [38, 40, 41, 42, 43, 44, 45, 46] # 长为 8 的列表
            self.seq_domain_vocab_sizes[domain] = [
                self.seq_vocab_sizes[domain][fid] for fid in sideinfo
            ] # 如 [745286, 19, 11, 1005, 3342, 12735, 7612, 18] # 长为 8 的列表

            # seq_max_lens: {'seq_a': 256, 'seq_b': 256, 'seq_c': 512, 'seq_d': 512}
            # max_len: from seq_max_lens arg; unspecified domains fall back to 256.
            self._seq_maxlen[domain] = seq_max_lens.get(domain, 256) # 如 256
        # print()
        # self.seq_feature_ids: 
        # {
        #     'seq_a': [38, 39, 40, 41, 42, 43, 44, 45, 46], # 长为 9 的列表
        #     'seq_b': [67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 88], # 长为 14 的列表
        #     'seq_c': [27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 47], # 长为 12 的列表
        #     'seq_d': [17, 18, 19, 20, 21, 22, 23, 24, 25, 26] # 长为 10 的列表
        # }

        # self.seq_vocab_sizes: 
        # {
        #     'seq_a': {
        #         38: 745286, 
        #         39: 0, 
        #         ...,
        #         45: 7612, 
        #         46: 18
        #     }, # 大小为 9 的 字典
        #     'seq_b': {
        #         67: 0, 
        #         68: 28,
        #         ...,
        #         79: 11387, 
        #         88: 199678
        #     }, # 大小为 14 的 字典
        #     'seq_c': {
        #         27: 0, 
        #         28: 73,
        #         ..., 
        #         37: 9433, 
        #         47: 86335515
        #     }, # 大小为 12 的 字典
        #     'seq_d': {
        #         17: 5, 
        #         18: 966, 
        #         ...,
        #         25: 15, 
        #         26: 0
        #     } # 大小为 10 的 字典
        # }

        # self.seq_domain_vocab_sizes: 
        # {
        #     'seq_a': [745286, 19, 11, 1005, 3342, 12735, 7612, 18],  # 长为 8 的列表
        #     'seq_b': [28, 64710562, 726, 2669, 10203, 6761, 476333, 31, 132080, 166, 4229, 11387, 199678], # 长为 13 的列表
        #     'seq_c': [73, 5764358, 846, 6805, 7, 5, 1031305, 2896, 977479, 9433, 86335515], # 长为 11 的列表
        #     'seq_d': [5, 966, 3300, 10785, 4929, 404398, 606041, 531, 15] # 长为 9 的列表
        # }

        # self.ts_fids: {'seq_a': 39, 'seq_b': 67, 'seq_c': 27, 'seq_d': 26}

        # self.sideinfo_fids: 
        # {
        #     'seq_a': [38, 40, 41, 42, 43, 44, 45, 46], # 长为 8 的列表
        #     'seq_b': [68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 88], # 长为 13 的列表
        #     'seq_c': [28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 47], # 长为 11 的列表
        #     'seq_d': [17, 18, 19, 20, 21, 22, 23, 24, 25] # 长为 9 的列表
        # }

        # self._seq_prefix: {'seq_a': 'domain_a_seq', 'seq_b': 'domain_b_seq', 'seq_c': 'domain_c_seq', 'seq_d': 'domain_d_seq'}

        # self._seq_maxlen: {'seq_a': 256, 'seq_b': 256, 'seq_c': 512, 'seq_d': 512}

    def __len__(self) -> int:
        # Ceiling per Row Group; this is an upper bound on the true batch count.
        return sum((n + self.batch_size - 1) // self.batch_size
                   for _, _, n in self._rg_list)

    def __iter__(self) -> Iterator[Dict[str, Any]]:
        worker_info = torch.utils.data.get_worker_info() # None
        rg_list = self._rg_list # [('/Users/wangyang/Downloads/taac26/data_sample_1000/demo_1000.parquet', 0, 1000)]
        if worker_info is not None and worker_info.num_workers > 1:
            rg_list = [rg for i, rg in enumerate(rg_list)
                       if i % worker_info.num_workers == worker_info.id]

        buffer: List[Dict[str, Any]] = []
        for file_path, rg_idx, _ in rg_list:
            pf = pq.ParquetFile(file_path) # '/Users/wangyang/Downloads/taac26/data_sample_1000/demo_1000.parquet'
            for batch in pf.iter_batches(batch_size=self.batch_size, row_groups=[rg_idx]):
                batch_dict = self._convert_batch(batch)
                # {
                #     'user_int_feats': tensor([[   4,    0,    6,  ...,    1,    0,    0],
                #                               [   4, 1137,  601,  ...,    1,    6,    0],
                #                               ...,
                #                               [   4,  645,  630,  ...,    1,    0,    0],
                #                               [   4, 1586,  653,  ...,    1,    2,    0]]),  # torch.Size([16, 411])
                #     'user_dense_feats': tensor([[ 1.0862e-01, -2.0586e-02,  9.2901e-02,  ..., -1.2180e-01,  -1.7900e-02, -2.5000e-03],
                #                                 [ 1.1631e-01,  7.9820e-02,  9.9188e-02,  ...,  0.0000e+00,  0.0000e+00,  0.0000e+00],
                #                                 ...,
                #                                 [ 1.2082e-01,  1.4171e-02,  8.8848e-02,  ..., -9.0100e-02, -1.3300e-02, -1.5000e-03],
                #                                 [ 7.1662e-02,  5.1777e-02,  8.8747e-02,  ...,  3.1310e-01, 4.6100e-02,  4.7000e-03]]),  # torch.Size([16, 918])
                #     'item_int_feats': tensor([[  161,   893,     0,     ...,     0,     0,     0],
                #                               [   90,   518,   455,     ...,    29,   134,   873],
                #                               ...,
                #                               [    8,   431,   927,     ...,    0,     0,     0],
                #                               [   23,   669,  1303,     ...,    0,     0,     0]]), # torch.Size([16, 33])
                #     'item_dense_feats': tensor([], size=(16, 0)), 
                #     'label': tensor([0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0]),  # torch.Size([16])
                #     'timestamp': tensor([1772725140, 1772725252, 1772725278, ..., 1772725172, 1772725277, 1772725304]), # torch.Size([16])
                #     'user_id': [3864676, 8507274, 11951382, ..., 10685860, 9976196, 8037367], # 长为 16 的列表
                #     '_seq_domains': ['seq_a', 'seq_b', 'seq_c', 'seq_d'], 
                #     'seq_a': tensor([[[     0,      0,      0,  ...,      0,      0,      0],
                #                       ...,
                #                       [    12,      1,      0,  ...,     14,      0,      0]],
                #                      [[     0,      0,      0,  ...,      0,      0,      0],
                #                       ...,
                #                       [    14,      1,      1,  ...,     16,     16,      1]],
                #                      ...,
                #                      [[     0,      0,      0,  ...,      0,      0,      0],
                #                       ...,
                #                       [    12,     16,     16,  ...,      1,     14,      1]],
                #                      [[     0,      0,      0,  ...,      0,      0, 196425],
                #                       ...,
                #                       [     1,      1,     17,  ...,     16,     16,     17]]]), # torch.Size([16, 8, 256])
                #     'seq_a_len': tensor([256, 256, 203, 256, 256, 256, 102, 256, 256,  78, 256, 256,  74, 256,  256, 256]), # torch.Size([16])
                #     'seq_a_time_bucket': tensor([[42, 48, 48,  ..., 61, 61, 61],
                #                                  [33, 33, 33,  ..., 59, 59, 59],
                #                                 ...,
                #                                  [34, 42, 42,  ..., 56, 56, 56],
                #                                  [22, 22, 22,  ..., 57, 57, 57]]), # torch.Size([16, 256])
                #     'seq_b': tensor([[[       6,       22,        6,  ...,       22,       22,       22],
                #                       ...,
                #                       [       0,        0,        0,  ...,        0,        0,        0]],
                #                      [[      25,       25,       25,  ...,       24,       24,        8],
                #                       ...,
                #                       [       0,        0,        0,  ...,        0,        0,    70448]],
                #                      ...,
                #                      [[       6,       25,       25,  ...,       19,       19,       19],
                #                       ...,
                #                       [       0,        0,        0,  ...,        0,   181624,   181624]],
                #                      [[       5,        5,        1,  ...,        6,        6,        6],
                #                       ...,
                #                       [    7547,     7547,        0,  ...,   117766,     1990,    72260]]]), # torch.Size([16, 13, 256])
                #     'seq_b_len': tensor([256, 256, 250, 256, 256,   7,  53, 239, 256,  32, 256, 256,   6, 256, 256, 256]), # torch.Size([16])
                #     'seq_b_time_bucket': tensor([[32, 40, 42,  ..., 57, 57, 57],
                #                                  [54, 54, 54,  ..., 60, 60, 60],
                #                                  ...,
                #                                  [48, 48, 49,  ..., 61, 61, 61],
                #                                  [16, 16, 22,  ..., 55, 55, 55]]), # torch.Size([16, 256])
                #     'seq_c': tensor([[[      31,       31,       31,  ...,        0,        0,        0],
                #                       ...,
                #                       [       0, 80211853,        0,  ...,        0,        0,        0]],
                #                      [[      31,       31,       31,  ...,        0,        0,        0],
                #                       ...,
                #                       [41727892, 82135815, 44760703,  ...,        0,        0,        0]],
                #                      ...,
                #                      [[      31,       31,       31,  ...,        0,        0,        0],
                #                       ...,
                #                       [79110698, 54451658,        0,  ...,        0,        0,        0]],
                #                      [[      31,       14,       31,  ...,        0,        0,        0],
                #                       ...,
                #                       [14547649,        0,        0,  ...,        0,        0,        0]]]), # torch.Size([16, 11, 512])
                #     'seq_c_len': tensor([333, 303, 512, 308, 395,  83, 301, 303, 327,  83, 512, 152, 432, 365, 266, 393]), # torch.Size([16])
                #     'seq_c_time_bucket': tensor([[48, 51, 52,  ...,  0,  0,  0],
                #                                  [51, 51, 52,  ...,  0,  0,  0],
                #                                  ...,
                #                                  [54, 54, 54,  ...,  0,  0,  0],
                #                                  [21, 24, 44,  ...,  0,  0,  0]]), # torch.Size([16, 512])
                #     'seq_d': tensor([[[     3,      3,      3,  ...,      3,      3,      3],
                #                       ...,
                #                       [     2,      2,      2,  ...,      2,      2,      2]],
                #                      [[     0,      0,      0,  ...,      0,      0,      0],
                #                       ...,
                #                       [     0,      0,      0,  ...,      0,      0,      0]],
                #                      ...,
                #                      [[     3,      3,      3,  ...,      3,      3,      3],
                #                       ...,
                #                       [     2,     13,     14,  ...,      2,     14,      2]],
                #                      [[     3,      3,      3,  ...,      3,      3,      3],
                #                       ...,
                #                       [    14,      2,      2,  ...,      8,     12,      8]]]), # torch.Size([16, 9, 512])
                #     'seq_d_len': tensor([512,   0, 297, 512, 485, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512]), # torch.Size([16])
                #     'seq_d_time_bucket': tensor([[24, 32, 32,  ..., 54, 54, 54],
                #                                  [ 0,  0,  0,  ...,  0,  0,  0],
                #                                  ...,
                #                                  [35, 37, 37,  ..., 52, 52, 52],
                #                                  [14, 22, 24,  ..., 54, 54, 54]]) # torch.Size([16, 512])
                # }
                if self.shuffle and self.buffer_batches > 1:
                    buffer.append(batch_dict) # 加一个 batch 到缓存区 buffer 里
                    # self.buffer_batches: 20 一次缓存 20 个 batch
                    if len(buffer) >= self.buffer_batches: # 缓存够 20 个 batch 才开始 shuffle
                        yield from self._flush_buffer(buffer)
                        # yield from self._flush_buffer(buffer) 等价于
                        # for x in self._flush_buffer(buffer):
                        #     yield x
                        # 意思是 把 buffer 里的 batch 打乱后，一个个吐出去
                        buffer = []
                else:
                    yield batch_dict

        if buffer:
            yield from self._flush_buffer(buffer)

        del buffer
        gc.collect()

    def _flush_buffer(
        self, buffer: List[Dict[str, Any]]
    ) -> Iterator[Dict[str, Any]]:
        """Concatenate the buffered batches, shuffle at the row level, then
        re-slice and yield batch-sized chunks.
        """
        merged: Dict[str, torch.Tensor] = {}
        non_tensor_keys: Dict[str, Any] = {}
        for k in buffer[0].keys():
            if isinstance(buffer[0][k], torch.Tensor):
                merged[k] = torch.cat([b[k] for b in buffer], dim=0) # 把buffer里的batch拼一起
            else:
                non_tensor_keys[k] = buffer[0][k]
        total_rows = merged['label'].shape[0]
        rand_idx = torch.randperm(total_rows) if self.shuffle else torch.arange(total_rows)
        for i in range(0, total_rows, self.batch_size):
            end = min(i + self.batch_size, total_rows)
            batch: Dict[str, Any] = {k: v[rand_idx[i:end]] for k, v in merged.items()}
            batch.update(non_tensor_keys)
            yield batch
        del merged
        buffer.clear()

    # ---- Helpers ----

    def _record_oob(
        self,
        group: str,
        col_idx: int,
        arr: "npt.NDArray[np.int64]",
        vocab_size: int,
    ) -> None:
        """Record out-of-bound indices and (optionally) clip them to 0,
        without printing to the console.
        """
        oob_mask = arr >= vocab_size
        if not oob_mask.any():
            return
        key = (group, col_idx)
        oob_vals = arr[oob_mask]
        n = int(oob_mask.sum())
        mx = int(oob_vals.max())
        mn = int(oob_vals.min())
        if key in self._oob_stats:
            s = self._oob_stats[key]
            s['count'] += n
            s['max'] = max(s['max'], mx)
            s['min_oob'] = min(s['min_oob'], mn)
        else:
            self._oob_stats[key] = {
                'count': n, 'max': mx, 'min_oob': mn, 'vocab': vocab_size,
            }
        if self.clip_vocab:
            arr[oob_mask] = 0
        else:
            raise ValueError(
                f"{group} col_idx={col_idx}: {n} values out of range "
                f"[0, {vocab_size}), actual=[{mn}, {mx}]. "
                f"Use clip_vocab=True to clip or fix schema.json")

    def dump_oob_stats(self, path: Optional[str] = None) -> None:
        """Dump out-of-bound statistics to a file if ``path`` is provided,
        otherwise to ``logging.info``.
        """
        if not self._oob_stats:
            logging.info("No out-of-bound values detected.")
            return
        lines = ["=== Out-of-Bound Stats ==="]
        for (group, ci), s in sorted(self._oob_stats.items()):
            direction = "TOO_HIGH" if s['min_oob'] >= s['vocab'] else "TOO_LOW"
            lines.append(
                f"  {group} col_idx={ci}: vocab={s['vocab']}, "
                f"oob_count={s['count']}, range=[{s['min_oob']}, {s['max']}], "
                f"{direction}")
        msg = "\n".join(lines)
        if path:
            with open(path, 'w') as f:
                f.write(msg + "\n")
            logging.info(f"OOB stats written to {path}")
        else:
            logging.info(msg)

    def _pad_varlen_int_column(
        self,
        arrow_col: "pa.ListArray",
        max_len: int,
        B: int,
    ) -> Tuple["npt.NDArray[np.int64]", "npt.NDArray[np.int64]"]:
        """Pad an Arrow ``ListArray`` of ints to shape ``[B, max_len]``.

        Values <= 0 are mapped to 0 (padding). Note: the raw data contains -1
        (missing); currently treated the same way as 0 (padding).

        Returns:
            A tuple ``(padded, lengths)`` where ``padded`` has shape
            ``[B, max_len]`` and ``lengths`` has shape ``[B]``.
        """
        offsets = arrow_col.offsets.to_numpy()
        values = arrow_col.values.to_numpy()

        padded = np.zeros((B, max_len), dtype=np.int64)
        lengths = np.zeros(B, dtype=np.int64)

        for i in range(B):
            start, end = int(offsets[i]), int(offsets[i + 1])
            raw_len = end - start
            if raw_len <= 0:
                continue
            use_len = min(raw_len, max_len)
            padded[i, :use_len] = values[start:start + use_len]
            lengths[i] = use_len

        padded[padded <= 0] = 0
        return padded, lengths

    # Backwards-compatible alias kept for bench_raw_dataset.py and other
    # external callers that pre-date the rename. New code should call
    # `_pad_varlen_int_column` directly.
    _pad_varlen_column = _pad_varlen_int_column

    def _pad_varlen_float_column(
        self,
        arrow_col: "pa.ListArray",
        max_dim: int,
        B: int,
    ) -> "npt.NDArray[np.float32]":
        """Pad an Arrow ``ListArray<float>`` to shape ``[B, max_dim]``."""
        offsets = arrow_col.offsets.to_numpy()
        values = arrow_col.values.to_numpy()

        padded = np.zeros((B, max_dim), dtype=np.float32)

        for i in range(B):
            start, end = int(offsets[i]), int(offsets[i + 1])
            raw_len = end - start
            if raw_len <= 0:
                continue
            use_len = min(raw_len, max_dim)
            padded[i, :use_len] = values[start:start + use_len]

        return padded

    def _convert_batch(self, batch: "pa.RecordBatch") -> Dict[str, Any]:
        """Convert an Arrow RecordBatch into a training-ready dict of tensors."""
        B = batch.num_rows # 16

        # ---- meta ----
        timestamps = batch.column(self._col_idx['timestamp']).to_numpy().astype(np.int64) # (16,)
        # array([1772725140, 1772725252, 1772725278, ..., 1772725172, 1772725277, 1772725304])
        if self.is_training: # 训练集和验证集
            labels = (batch.column(self._col_idx['label_type']).fill_null(0)
                      .to_numpy(zero_copy_only=False).astype(np.int64) == 2).astype(np.int64)
            # self._col_idx['label_type']: 2
            # batch.column(self._col_idx['label_type']): 长为 16 的列表
            # [1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1]
    
            # batch.column(self._col_idx['label_type']).fill_null(0).to_numpy(zero_copy_only=False).astype(np.int64): (16,)
            # array([1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1]) 

            # labels: (16,)
            # array([0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0]) 
        else: # 测试集
            labels = np.zeros(B, dtype=np.int64)
        user_ids = batch.column(self._col_idx['user_id']).to_pylist()
        # self._col_idx['user_id']): 0
        # user_ids: 长为 16 的列表
        # [3864676, 8507274, 11951382, ..., 10685860, 9976196, 8037367]

        # ---- user_int: write into pre-allocated buffer ----
        # Note: null -> 0 (via fill_null), -1 -> 0 (via arr<=0); missing values
        # are treated the same as padding. Features with vs==0 have no vocab
        # information and are forced to 0 on the dataset side so that the
        # model's 1-slot Embedding (created for vs=0) is never indexed out of
        # range.

        # self._buf_user_int: (16, 411)
        # array([[0, 0, 0, ..., 0, 0, 0],
        #        [0, 0, 0, ..., 0, 0, 0],
        #        ...,
        #        [0, 0, 0, ..., 0, 0, 0],
        #        [0, 0, 0, ..., 0, 0, 0]])
        user_int = self._buf_user_int[:B] # (16, 411)
        # array([[0, 0, 0, ..., 0, 0, 0],
        #        [0, 0, 0, ..., 0, 0, 0],
        #        ...,
        #        [0, 0, 0, ..., 0, 0, 0],
        #        [0, 0, 0, ..., 0, 0, 0]])
        user_int[:] = 0

        # self._user_int_plan: 长为 46 的列表
        # [(5, 1, 0, 6), (6, 1, 1, 1725), (7, 1, 2, 957), 
        #  (8, 26, 3, 1167), (9, 1, 29, 101), (10, 1, 30, 3), 
        #  ..., 
        #  (48, 1, 408, 4), (49, 1, 409, 8), (50, 1, 410, 8)]
        for ci, dim, offset, vs in self._user_int_plan:
            col = batch.column(ci)
            if dim == 1: # 单值特征
                # ci 如 5，dim 如 1，offset 如 0，vs 如 6
                # col 如 长为 16 的列表
                # [4, 4, 4, 4, 2, 1, 4, 4, 4, 1, 4, 4, 4, 4, 4, 4] 
                arr = col.fill_null(0).to_numpy(zero_copy_only=False).astype(np.int64) # (16,)
                # array([4, 4, 4, 4, 2, 1, 4, 4, 4, 1, 4, 4, 4, 4, 4, 4])
                arr[arr <= 0] = 0
                if vs > 0:
                    self._record_oob('user_int', ci, arr, vs)
                else:
                    arr[:] = 0
                # offset: 0
                # user_int[:, offset]: (16,)
                # array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
                user_int[:, offset] = arr # user_int[:, 0] = arr 将 user_int 的第 0 列赋值为 arr
                # 例如 user_int 从
                # array([[0, 0, 0, ..., 0, 0, 0],
                #        [0, 0, 0, ..., 0, 0, 0],
                #        ...,
                #        [0, 0, 0, ..., 0, 0, 0],
                #        [0, 0, 0, ..., 0, 0, 0]]) # (16, 411)
                # 变为
                # array([[4, 0, 0, ..., 0, 0, 0],
                #        [4, 0, 0, ..., 0, 0, 0],
                #        ...,
                #        [4, 0, 0, ..., 0, 0, 0],
                #        [4, 0, 0, ..., 0, 0, 0]]) # (16, 411)
            else: # array 型特征
                # ci 如 8，dim 如 26，offset 如 3，vs 如 1167
                # col 如 长为 16 的列表，列表中每个元素也是一个列表，但长度不同
                # [[928, 556, 538, 739, 94],
                #  [147, 50, 757],
                #  ...,
                #  [982, 565, 175],
                #  [175, 252, 535, 1167, 591]] 
                padded, _ = self._pad_varlen_int_column(col, dim, B)
                # padded: (16, 26)
                # array([[ 928,  556,  538,  739,   94,    0,    ...,    0,    0,    0],
                #        [ 147,   50,  757,    0,    0,    0,    ...,    0,    0,    0],
                #        [ 982,  349,  387,  974,  976,  213,    ...,    0,    0,    0],
                #        ...,
                #        [1021,  350,  767,  642,  396,    0,    ...,    0,    0,    0],
                #        [ 982,  565,  175,    0,    0,    0,    ...,    0,    0,    0],
                #        [ 175,  252,  535, 1167,  591,    0,    ...,    0,    0,    0]])

                # _: (16,)
                # array([5, 3, 6, 5, 3, 0, 3, 4, 1, 2, 6, 4, 1, 5, 3, 5])
                if vs > 0:
                    self._record_oob('user_int', ci, padded, vs)
                else:
                    padded[:] = 0
                # offset: 3, dim: 26
                user_int[:, offset:offset + dim] = padded # user_int[:, 3:3 + 26] = padded 将 user_int 的第 3 - 29 列赋值为 padded
                # 例如 user_int 从
                # array([[   4,    0,    6,    0,    0,    0,    0,    0,    0,    0,    ...,    0,    0,    0],
                #        [   4, 1137,  601,    0,    0,    0,    0,    0,    0,    0,    ...,    0,    0,    0],
                #        [   4, 1295,   63,    0,    0,    0,    0,    0,    0,    0,    ...,    0,    0,    0],
                #        ...,
                #        [   4,  523,  793,    0,    0,    0,    0,    0,    0,    0,    ...,    0,    0,    0],
                #        [   4,  645,  630,    0,    0,    0,    0,    0,    0,    0,    ...,    0,    0,    0],
                #        [   4, 1586,  653,    0,    0,    0,    0,    0,    0,    0,    ...,    0,    0,    0]]) # (16, 411)
                # 变为
                # array([[   4,    0,    6,  928,  556,  538,  739,   94,    0,    0,    ...,    0,    0,    0],
                #        [   4, 1137,  601,  147,   50,  757,    0,    0,    0,    0,    ...,    0,    0,    0],
                #        [   4, 1295,   63,  982,  349,  387,  974,  976,  213,    0,    ...,    0,    0,    0],
                #        ...,
                #        [   4,  523,  793, 1021,  350,  767,  642,  396,    0,    0,    ...,    0,    0,    0],
                #        [   4,  645,  630,  982,  565,  175,    0,    0,    0,    0,    ...,    0,    0,    0],
                #        [   4, 1586,  653,  175,  252,  535,    0,  591,    0,    0,    ...,    0,    0,    0]]) # (16, 411)
        # user_int: (16, 411)
        # array([[   4,    0,    6, ...,    1,    0,    0],
        #        [   4, 1137,  601, ...,    1,    6,    0],
        #        [   4, 1295,   63, ...,    0,    0,    0],
        #        ...,
        #        [   4,  523,  793, ...,    2,    0,    0],
        #        [   4,  645,  630, ...,    1,    0,    0],
        #        [   4, 1586,  653, ...,    1,    2,    0]])

        # ---- item_int ----
        item_int = self._buf_item_int[:B] # (16, 33)
        item_int[:] = 0
        for ci, dim, offset, vs in self._item_int_plan:
            # ci 如 61，dim 如 1，offset 如 0，vs 如 309
            col = batch.column(ci)
            if dim == 1:
                arr = col.fill_null(0).to_numpy(zero_copy_only=False).astype(np.int64)
                arr[arr <= 0] = 0
                if vs > 0:
                    self._record_oob('item_int', ci, arr, vs)
                else:
                    arr[:] = 0
                item_int[:, offset] = arr
            else:
                padded, _ = self._pad_varlen_int_column(col, dim, B)
                if vs > 0:
                    self._record_oob('item_int', ci, padded, vs)
                else:
                    padded[:] = 0
                item_int[:, offset:offset + dim] = padded
        # item_int: (16, 33)
        # array([[  161,   893,     0,     0,    30,    64,  2980,  2770,     0,     0,     ...,     0,     6, 18629,     0,     0,     0,     0],
        #        [   90,   518,   455,  1035,    29,   214,  2025, 12163,     0,     0,     ...,  1509,     2,  8764,     2,    29,   134,   873],
        #        ...,
        #        [    8,   431,   927,    79,    27,    17,  7719,     0,     0,     0,     ...,   835,     2, 19525,     0,     0,     0,     0],
        #        [   23,   669,  1303,   344,    31,    56,     0,     0,     0,     0,     ...,  1171,     8,  9795,     1,     0,     0,     0]])

        # ---- user_dense ----
        user_dense = self._buf_user_dense[:B] # (16, 918)
        user_dense[:] = 0
        for idx, (ci, dim, offset) in enumerate(self._user_dense_plan):
            # ci 如 51，dim 如 256，offset 如 0
            col = batch.column(ci)
            padded = self._pad_varlen_float_column(col, dim, B)
            # print(f"-----------------------------{self._ci_2_fea_name[ci]} 统计信息：-----------------------------")
            # print(f"shape: {padded.shape}, max: {padded.max():.4f}, min: {padded.min():.4f}, mean: {padded.mean():.4f}, std: {padded.std():.4f}")
            # print("----------------------------------------------------------------------------------------\n")
            # -----------------------------user_dense_feats_61 统计信息：-----------------------------
            # shape: (16, 256), max: 0.1734, min: -0.1812, mean: -0.0015, std: 0.0624
            # ----------------------------------------------------------------------------------------

            # -----------------------------user_dense_feats_62 统计信息：-----------------------------
            # shape: (16, 6), max: 1525911.3750, min: 0.0000, mean: 43937.4648, std: 172584.3281
            # ----------------------------------------------------------------------------------------

            # -----------------------------user_dense_feats_63 统计信息：-----------------------------
            # shape: (16, 19), max: 1252132.7500, min: 0.0000, mean: 14246.4043, std: 87630.5234
            # ----------------------------------------------------------------------------------------

            # -----------------------------user_dense_feats_64 统计信息：-----------------------------
            # shape: (16, 26), max: 1525911.3750, min: 0.0000, mean: 13881.9902, std: 90183.1875
            # ----------------------------------------------------------------------------------------

            # -----------------------------user_dense_feats_65 统计信息：-----------------------------
            # shape: (16, 111), max: 4476106.0000, min: 0.0000, mean: 5428.8472, std: 110344.9297
            # ----------------------------------------------------------------------------------------

            # -----------------------------user_dense_feats_66 统计信息：-----------------------------
            # shape: (16, 150), max: 4476106.0000, min: 0.0000, mean: 5216.5898, std: 99296.1875
            # ----------------------------------------------------------------------------------------

            # -----------------------------user_dense_feats_87 统计信息：-----------------------------
            # shape: (16, 320), max: 0.5249, min: -0.6280, mean: -0.0049, std: 0.1217
            # ----------------------------------------------------------------------------------------

            # -----------------------------user_dense_feats_89 统计信息：-----------------------------
            # shape: (16, 10), max: 0.7821, min: -0.6618, mean: -0.0000, std: 0.3162
            # ----------------------------------------------------------------------------------------

            # -----------------------------user_dense_feats_90 统计信息：-----------------------------
            # shape: (16, 10), max: 0.7818, min: -0.6618, mean: -0.0001, std: 0.3062
            # ----------------------------------------------------------------------------------------

            # -----------------------------user_dense_feats_91 统计信息：-----------------------------
            # shape: (16, 10), max: 0.8733, min: -0.6340, mean: -0.0000, std: 0.2500
            # ----------------------------------------------------------------------------------------
            # self._dense_transforms:
            # ['none', 'log1p_scale', 'log1p_scale', 'log1p_scale', 'log1p_scale', 'log1p_scale', 'none', 'none', 'none', 'none']
            transform = self._dense_transforms[idx]
            if self.scale_dense and transform == 'log1p_scale':
                padded = np.log1p(padded) / 20.0
                # print(f"-----------------------log scale 后 {self._ci_2_fea_name[ci]} 统计信息：-----------------------")
                # print(f"shape: {padded.shape}, max: {padded.max():.4f}, min: {padded.min():.4f}, mean: {padded.mean():.4f}, std: {padded.std():.4f}")
                # print("----------------------------------------------------------------------------------------\n")
                # -----------------------log scale 后 user_dense_feats_62 统计信息：-----------------------
                # shape: (16, 6), max: 0.7119, min: 0.0000, mean: 0.2105, std: 0.2524
                # ----------------------------------------------------------------------------------------

                # -----------------------log scale 后 user_dense_feats_63 统计信息：-----------------------
                # shape: (16, 19), max: 0.7020, min: 0.0000, mean: 0.0748, std: 0.1812
                # ----------------------------------------------------------------------------------------

                # -----------------------log scale 后 user_dense_feats_64 统计信息：-----------------------
                # shape: (16, 26), max: 0.7119, min: 0.0000, mean: 0.0814, std: 0.1854
                # ----------------------------------------------------------------------------------------

                # -----------------------log scale 后 user_dense_feats_65 统计信息：-----------------------
                # shape: (16, 111), max: 0.7657, min: 0.0000, mean: 0.0223, std: 0.1036
                # ----------------------------------------------------------------------------------------

                # -----------------------log scale 后 user_dense_feats_66 统计信息：-----------------------
                # shape: (16, 150), max: 0.7657, min: 0.0000, mean: 0.0191, std: 0.0970
                # ----------------------------------------------------------------------------------------
            user_dense[:, offset:offset + dim] = padded
        # user_dense: (16, 918)
        # array([[ 1.0862021e-01, -2.0586327e-02,  9.2900857e-02, ...,  -1.2180000e-01, -1.7899999e-02, -2.4999999e-03],
        #        [ 1.1631467e-01,  7.9820171e-02,  9.9188074e-02, ...,   0.0000000e+00,  0.0000000e+00,  0.0000000e+00],
        #        ...,
        #        [ 1.2082158e-01,  1.4170501e-02,  8.8848040e-02, ...,  -9.0099998e-02, -1.3300000e-02, -1.5000000e-03],
        #        [ 7.1661629e-02,  5.1776893e-02,  8.8747472e-02, ...,   3.1310001e-01,  4.6100002e-02,  4.6999999e-03]], dtype=float32)
        result = {
            'user_int_feats': torch.from_numpy(user_int.copy()),
            'user_dense_feats': torch.from_numpy(user_dense.copy()),
            'item_int_feats': torch.from_numpy(item_int.copy()),
            'item_dense_feats': torch.zeros(B, 0, dtype=torch.float32),
            'label': torch.from_numpy(labels),
            'timestamp': torch.from_numpy(timestamps),
            'user_id': user_ids,
            '_seq_domains': self.seq_domains,
        }

        # ---- Sequence features: fused padding directly into the 3D buffer ----
        for domain in self.seq_domains:
            # domain 如 'seq_a'
            # self._seq_maxlen: {'seq_a': 256, 'seq_b': 256, 'seq_c': 512, 'seq_d': 512}
            max_len = self._seq_maxlen[domain] # 256
            # self._seq_plan:
            # {
            #     'seq_a': ([ # 长为 8 的列表
            #         (75, 0, 745286), (77, 1, 19), (78, 2, 11), 
            #         (79, 3, 1005), (80, 4, 3342), (81, 5, 12735), 
            #         (82, 6, 7612), (83, 7, 18)
            #         ], 76
            #     ), 
            #     'seq_b': ([ # 长为 13 的列表
            #         (85, 0, 28), (86, 1, 64710562), (87, 2, 726), 
            #         (88, 3, 2669), (89, 4, 10203), (90, 5, 6761), 
            #         (91, 6, 476333), (92, 7, 31), (93, 8, 132080), 
            #         (94, 9, 166), (95, 10, 4229), (96, 11, 11387), (97, 12, 199678)
            #         ], 84
            #     ), 
            #     'seq_c': ([ # 长为 11 的列表
            #         (99, 0, 73), (100, 1, 5764358), (101, 2, 846), 
            #         (102, 3, 6805), (103, 4, 7), (104, 5, 5), 
            #         (105, 6, 1031305), (106, 7, 2896), (107, 8, 977479), 
            #         (108, 9, 9433), (109, 10, 86335515)
            #         ], 98
            #     ), 
            #     'seq_d': ([ # 长为 9 的列表
            #         (110, 0, 5), (111, 1, 966), (112, 2, 3300), 
            #         (113, 3, 10785), (114, 4, 4929), (115, 5, 404398), 
            #         (116, 6, 606041), (117, 7, 531), (118, 8, 15)
            #         ], 119
            #     )
            # }
            side_plan, ts_ci = self._seq_plan[domain] 
            # side_plan 如 [(75, 0, 745286), (77, 1, 19), (78, 2, 11), (79, 3, 1005), (80, 4, 3342), (81, 5, 12735), (82, 6, 7612), (83, 7, 18)]
            # ts_ci 如 76

            # self._buf_seq:
            # {
            #     'seq_a': array([[[0, 0, 0, ..., 0, 0, 0],
            #                      ...,
            #                      [0, 0, 0, ..., 0, 0, 0]],
            #                     ...,
            #                     [[0, 0, 0, ..., 0, 0, 0],
            #                      ...,
            #                      [0, 0, 0, ..., 0, 0, 0]]]), # (16, 8, 256)
            #     'seq_b': array([[[0, 0, 0, ..., 0, 0, 0],
            #                      ...,
            #                      [0, 0, 0, ..., 0, 0, 0]],
            #                     ...,
            #                     [[0, 0, 0, ..., 0, 0, 0],
            #                      ...,
            #                      [0, 0, 0, ..., 0, 0, 0]]]), # (16, 13, 256)
            #     'seq_c': array([[[0, 0, 0, ..., 0, 0, 0],
            #                      ...,
            #                      [0, 0, 0, ..., 0, 0, 0]],
            #                     ...,
            #                     [[0, 0, 0, ..., 0, 0, 0],
            #                      ...,
            #                      [0, 0, 0, ..., 0, 0, 0]]]), # (16, 11, 512)
            #     'seq_d': array([[[0, 0, 0, ..., 0, 0, 0],
            #                      ...,
            #                      [0, 0, 0, ..., 0, 0, 0]],
            #                     ...,
            #                     [[0, 0, 0, ..., 0, 0, 0],
            #                      ...,
            #                      [0, 0, 0, ..., 0, 0, 0]]]) # (16, 9, 512)
            # }
            # Write directly into the pre-allocated 3D buffer.
            out = self._buf_seq[domain][:B] # 如 (16, 8, 256)
            out[:] = 0
            # self._buf_seq_lens:
            # {
            #     'seq_a': array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]), # (16,)
            #     'seq_b': array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]), # (16,)
            #     'seq_c': array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]), # (16,)
            #     'seq_d': array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])  # (16,)
            # }
            lengths = self._buf_seq_lens[domain][:B] # (16,)
            lengths[:] = 0

            # Fused path: first collect (offsets, values, vocab_size, col_idx)
            # for every side-info column, then fill the buffer in a single pass.
            col_data = []
            for ci, slot, vs in side_plan: 
                # ci 如 75, slot 如 0, vs 如 745286
                col = batch.column(ci) # 长为 16 的列表 
                # [[0, 0, 0, 764162, 0, 0, 0, 0, 502217, 0, ..., 0, 0, 0, 0, 0, 0, 0, 344525, 341445, 553691],
                #  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ..., 498832, 706046, 761349, 156017, 61669, 467611, 347842, 673297, 401175, 61669],
                #  ...,
                #  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ..., 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                #  [0, 0, 0, 97065, 0, 0, 0, 0, 29583, 0, ..., 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]] 

                # col.offsets.to_numpy(): (17,)
                # array([0, 682, 1821, 2024, 2505, 3978, 4273, 4375, 4959, 6728, 6806, 8603, 9411, 9485, 11041, 12782, 13665], dtype=int32)

                # col.values.to_numpy(): (13665,)
                # array([0, 0, 0, 764162, 0, 0, 0, 0, 502217, 0, ..., 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
                col_data.append((col.offsets.to_numpy(), col.values.to_numpy(), vs, ci))
            # col_data: 长为 8 的列表 
            # [
            #     (
            #         array([0, 682, 1821, 2024, 2505, 3978, 4273, 4375, 4959, 6728, 6806, 8603, 9411, 9485, 11041, 12782, 13665], dtype=int32) # (17,)
            #         array([0, 0, 0, 764162, 0, 0, 0, 0, 502217, 0, ..., 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]), # (13665,)
            #         745286, 
            #         75
            #     ),
            #     (
            #         array([0,   682,  1821,  2024,  2505,  3978,  4273,  4375,  4959,  6728,  6806,  8603,  9411,  9485, 11041, 12782, 13665], dtype=int32), # (17,)
            #         array([2,  2,  7, ..., 13, 13, 13]), # (13665,)
            #         19, 
            #         77
            #     ), 
            #     (
            #         array([0,   682,  1821,  2024,  2505,  3978,  4273,  4375,  4959,  6728,  6806,  8603,  9411,  9485, 11041, 12782, 13665], dtype=int32), # (17,)
            #         array([6,  6, 11, ..., 10, 10, 10]), # (13665,)
            #         11, 
            #         78
            #     ), 
            #     (
            #         array([0,   682,  1821,  2024,  2505,  3978,  4273,  4375,  4959,  6728,  6806,  8603,  9411,  9485, 11041, 12782, 13665], dtype=int32), # (17,)
            #         array([840, 840,   0, ...,   0,   0,   0]), # (13665,)
            #         1005, 
            #         79
            #     ), 
            #     (
            #         array([0,   682,  1821,  2024,  2505,  3978,  4273,  4375,  4959,  6728,  6806,  8603,  9411,  9485, 11041, 12782, 13665], dtype=int32), # (17,)
            #         array([1365, 2046,    0, ...,    0,    0,    0]), # (13665,)
            #         3342, 
            #         80
            #     ), 
            #     (
            #         array([0,   682,  1821,  2024,  2505,  3978,  4273,  4375,  4959,  6728,  6806,  8603,  9411,  9485, 11041, 12782, 13665], dtype=int32), # (17,)
            #         array([3792, 5577,    0, ...,    0,    0,    0]), # (13665,)
            #         12735, 
            #         81
            #     ), 
            #     (
            #         array([0,   682,  1821,  2024,  2505,  3978,  4273,  4375,  4959,  6728,  6806,  8603,  9411,  9485, 11041, 12782, 13665], dtype=int32), # (17,)
            #         array([0, 0, 0, ..., 0, 0, 0]), # (13665,)
            #         7612, 
            #         82
            #     ),
            #     (
            #         array([0, 682, 1821, 2024, 2505, 3978, 4273, 4375, 4959, 6728, 6806, 8603, 9411, 9485, 11041, 12782, 13665], dtype=int32), # (17,)
            #         array([12,  1,  0,  0,  1,  1, 14, 11,  0, 16, ..., 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]) # (13665,)
            #         18, 
            #         83
            #     )
            # ]

            for c, (offs, vals, vs, ci) in enumerate(col_data):
                # c 如 0
                # offs 如 array([0, 682, 1821, 2024, 2505, 3978, 4273, 4375, 4959, 6728, 6806, 8603, 9411, 9485, 11041, 12782, 13665], dtype=int32) 
                # vals 如 array([0, 0, 0, 764162, 0, 0, 0, 0, 502217, 0, ..., 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]), # (13665,)
                # vs 如 745286
                # ci 如 75

                # B: 16
                for i in range(B):
                    # i 如 0
                    s = int(offs[i]) # 如 0
                    e = int(offs[i + 1]) # 如 682
                    rl = e - s # 如 682 - 0 = 682
                    if rl <= 0:
                        continue
                    ul = min(rl, max_len) # 如 min(682, 256) = 256
                    # 数据集中 a b c d 四个域的序列组织时，每个域序列均按时间戳降序排序，越靠前时间戳越大
                    out[i, c, :ul] = vals[s:s + ul] # 取序列前ul个元素即最近的ul个行为 如 vals[0:0 + 256] # (256,)
                    # vals[0:0 + 256] 如 array([0, 0, 0, 764162, 0, 0, 0, 0, 502217, 0, ..., 0, 480277, 0, 0, 0, 0, 0, 0, 0, 0])
                    # out 从 如                    
                    # array([[[0, 0, 0, ..., 0, 0, 0],
                    #         [0, 0, 0, ..., 0, 0, 0],
                    #         ...,
                    #         [0, 0, 0, ..., 0, 0, 0],
                    #         [0, 0, 0, ..., 0, 0, 0]],
                    #         ...,
                    #        [[0, 0, 0, ..., 0, 0, 0],
                    #         [0, 0, 0, ..., 0, 0, 0],
                    #         ...,
                    #         [0, 0, 0, ..., 0, 0, 0],
                    #         [0, 0, 0, ..., 0, 0, 0]]]), # (16, 8, 256)
                    # 变为
                    # array([[[0, 0, 0, 764162, 0, 0, 0, 0, 502217, 0, ..., 0, 480277, 0, 0, 0, 0, 0, 0, 0, 0],
                    #         [0, 0, 0, ..., 0, 0, 0],
                    #         ...,
                    #         [0, 0, 0, ..., 0, 0, 0],
                    #         [0, 0, 0, ..., 0, 0, 0]],
                    #         ...,
                    #        [[0, 0, 0, ..., 0, 0, 0],
                    #         [0, 0, 0, ..., 0, 0, 0],
                    #         ...,
                    #         [0, 0, 0, ..., 0, 0, 0],
                    #         [0, 0, 0, ..., 0, 0, 0]]]), # (16, 8, 256)
                    if ul > lengths[i]:
                        lengths[i] = ul
                    # lengths 从如
                    # array([0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0]) # (16,)
                    # 变为
                    # array([256,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0]) # (16,)
                    
            # out 如: (16, 8, 256)
            # array([[[     0,      0,      0, ...,      0,      0,      0],
            #         [     2,      2,      7, ...,      2,      7,      1],
            #         ...,
            #         [     0,      0,      0, ...,      0,      0,      0],
            #         [    12,      1,      0, ...,     14,      0,      0]],
            #        [[     0,      0,      0, ...,      0,      0,      0],
            #         [     2,      2,      2, ...,      2,      2,      2],
            #         ...,
            #         [     0,      0,      0, ...,      0,      0,      0],
            #         [    14,      1,      1, ...,     16,     16,      1]],
            #        ...,
            #        [[     0,      0,      0, ...,      0,      0,      0],
            #         [     2,      2,      2, ...,      2,      2,      2],
            #         ...,
            #         [     0,      0,      0, ...,      0,      0,      0],
            #         [    12,     16,     16, ...,      1,     14,      1]],
            #        [[     0,      0,      0, ...,      0,      0, 196425],
            #         [     2,      2,     13, ...,      2,      2,     13],
            #         ...,
            #         [     0,      0,   2308, ...,      0,      0,   6598],
            #         [     1,      1,     17, ...,     16,     16,     17]]])

            # lengths 如 (16,)
            # array([256, 256, 203, 256, 256, 256, 102, 256, 256,  78, 256, 256,  74,  256, 256, 256])

            # Values <= 0 -> 0.
            out[out <= 0] = 0

            # Check out-of-bound values per feature's vocab_size.
            # vs==0 means no vocab info; force the whole slice to 0 so that
            # the model's 1-slot Embedding is never indexed out of range.
            for c, (_, _, vs, ci) in enumerate(col_data):
                # c 如 0, vs 如 745286, ci 如 75
                slice_c = out[:, c, :]
                if vs > 0:
                    self._record_oob(f'seq_{domain}', ci, slice_c, vs)
                else:
                    slice_c[:] = 0
            # domain 如 'seq_a', f'{domain}_len' 如 'seq_a_len'
            result[domain] = torch.from_numpy(out.copy()) # (16, 8, 256)
            result[f'{domain}_len'] = torch.from_numpy(lengths.copy()) # (16,)

            # Time bucketing. 把序列中每个历史行为发生的时间，编码成一个"距离当前时间有多远"的分桶 ID，让模型知道行为的新旧程度
            time_bucket = self._buf_seq_tb[domain][:B] # (16, 256)
            # array([[0, 0, 0, ..., 0, 0, 0],
            #        [0, 0, 0, ..., 0, 0, 0],
            #        ...,
            #        [0, 0, 0, ..., 0, 0, 0],
            #        [0, 0, 0, ..., 0, 0, 0]])
            time_bucket[:] = 0
            if ts_ci is not None:
                ts_col = batch.column(ts_ci) # 长为 16 的列表, 列表中每个元素是长度不同的列表
                # [[1772695320, 1772626560, 1772603941, ..., 1748930818, 1744007309, 1744007301],
                #  [1772718480, 1772718420, 1772718180, ..., 1746166052, 1745561608, 1745235927],
                #  ...,
                #  [1772716740, 1772703660, 1772703480, ..., 1760114400, 1760110980, 1760108640],
                #  [1772724540, 1772724480, 1772724415, ..., 1729958399, 1729526399, 1721836799]] 
                ts_offs = ts_col.offsets.to_numpy() # (17,)
                # array([    0,   682,  1821,  2024,  2505,  3978,  4273,  4375,  4959,   6728,  6806,  8603,  9411,  9485, 11041, 12782, 13665], dtype=int32)
                ts_vals = ts_col.values.to_numpy() # (10949,)
                # array([1772695320, 1772626560, 1772603941, ..., 1729958399, 1729526399,  1721836799])
                # Pad timestamps into shape (B, max_len).
                ts_padded = np.zeros((B, max_len), dtype=np.int64) # (16, 256)
                for i in range(B):
                    s = int(ts_offs[i]) # 如 0
                    e = int(ts_offs[i + 1]) # 如 682
                    rl = e - s # 如 682 - 0 = 682
                    if rl <= 0:
                        continue
                    ul = min(rl, max_len) # 如 min(682, 256) = 256
                    ts_padded[i, :ul] = ts_vals[s:s + ul]
                    # ts_padded 从 如
                    # array([[0, 0, 0, ..., 0, 0, 0],
                    #        [0, 0, 0, ..., 0, 0, 0],
                    #        ...,
                    #        [0, 0, 0, ..., 0, 0, 0],
                    #        [0, 0, 0, ..., 0, 0, 0]]) # (16, 256)
                    # 变成 
                    # array([[1772695320, 1772626560, 1772603941, ..., 1764850140, 1764816666, 1764814919],
                    #        [         0,          0,          0, ...,          0,          0,          0],
                    #        ...,
                    #        [         0,          0,          0, ...,          0,          0,          0],
                    #        [         0,          0,          0, ...,          0,          0,          0]]) # (16, 256)
                # ts_padded: (16, 256)
                # array([[1772695320, 1772626560, 1772603941, ..., 1764850140, 1764816666, 1764814919],
                #        [1772718480, 1772718420, 1772718180, ..., 1768139700, 1768139640, 1768139100],
                #        [1772723280, 1772682120, 1772682060, ...,          0,          0,          0],
                #        ...,
                #        [1772708040, 1772705940, 1772705880, ..., 1770527160, 1770519660, 1770519560],
                #        [1772716740, 1772703660, 1772703480, ..., 1770878700, 1770870660, 1770870540],
                #        [1772724540, 1772724480, 1772724415, ..., 1770458220, 1770457500, 1770457412]])
                ts_expanded = timestamps.reshape(-1, 1) # (16, 1)
                # array([[1772725140],
                #        [1772725252],
                #        ...,
                #        [1772725277],
                #        [1772725304]])
                time_diff = np.maximum(ts_expanded - ts_padded, 0) # (16, 256) # 当前请求的item距离历史行为序列中各个行为的时间差
                # array([[     29820,      98580,     121199, ...,    7875000,    7908474,    7910221],
                #        [      6772,       6832,       7072, ...,    4585552,    4585612,    4586152],
                #        ...,
                #        [      8537,      21617,      21797, ...,    1846577,    1854617,    1854737],
                #        [       764,        824,        889, ...,    2267084,    2267804,    2267892]])

                # np.searchsorted 返回的值范围为 [0, len(BUCKET_BOUNDARIES)]
                # +1 之后，理论范围变为 [1, len(BUCKET_BOUNDARIES)+1]；
                # 但当 time_diff 超过最大边界（约 1 年）时，上界值会出现，
                # 这会导致索引超出 nn.Embedding 的合法范围（NUM_TIME_BUCKETS = len(BUCKET_BOUNDARIES)+1）。
                # 因此我们将原始结果裁剪到 [0, len(BUCKET_BOUNDARIES)-1]，使最终的
                # bucket id（加 1 之后）始终落在 [1, len(BUCKET_BOUNDARIES)] 范围内，
                # 保证是合法的 Embedding 索引。超过最大边界的 time_diff 将被归入最后一个 bucket
                # BUCKET_BOUNDARIES: # (63,)
                # array([       5,       10,       15,       20,       25,       30,
                #              35,       40,       45,       50,       55,       60,
                #             120,      180,      240,      300,      360,      420,
                #             480,      540,      600,      900,     1200,     1500,
                #            1800,     2100,     2400,     2700,     3000,     3300,
                #            3600,     5400,     7200,     9000,    10800,    12600,
                #           14400,    16200,    18000,    19800,    21600,    32400,
                #           43200,    54000,    64800,    75600,    86400,   172800,
                #          259200,   345600,   432000,   518400,   604800,  1123200,
                #         1641600,  2160000,  2592000,  4320000,  6048000,  7776000,
                #        11664000, 15552000, 31536000])
                raw_buckets = np.clip(
                    np.searchsorted(BUCKET_BOUNDARIES, time_diff.ravel()),
                    0, len(BUCKET_BOUNDARIES) - 1,
                ) # (4096,)
                # array([41, 47, 47, ..., 56, 56, 56])
                buckets = raw_buckets.reshape(B, max_len) + 1 # (16, 256)
                # array([[42, 48, 48, ..., 61, 61, 61],
                #        [33, 33, 33, ..., 59, 59, 59],
                #        ...,
                #        [34, 42, 42, ..., 56, 56, 56],
                #        [22, 22, 22, ..., 57, 57, 57]])
                buckets[ts_padded == 0] = 0
                time_bucket[:] = buckets

            result[f'{domain}_time_bucket'] = torch.from_numpy(time_bucket.copy())
        # {
        #     'user_int_feats': tensor([[   4,    0,    6,  ...,    1,    0,    0],
        #                               [   4, 1137,  601,  ...,    1,    6,    0],
        #                               ...,
        #                               [   4,  645,  630,  ...,    1,    0,    0],
        #                               [   4, 1586,  653,  ...,    1,    2,    0]]),  # torch.Size([16, 411])
        #     'user_dense_feats': tensor([[ 1.0862e-01, -2.0586e-02,  9.2901e-02,  ..., -1.2180e-01,  -1.7900e-02, -2.5000e-03],
        #                                 [ 1.1631e-01,  7.9820e-02,  9.9188e-02,  ...,  0.0000e+00,  0.0000e+00,  0.0000e+00],
        #                                 ...,
        #                                 [ 1.2082e-01,  1.4171e-02,  8.8848e-02,  ..., -9.0100e-02, -1.3300e-02, -1.5000e-03],
        #                                 [ 7.1662e-02,  5.1777e-02,  8.8747e-02,  ...,  3.1310e-01, 4.6100e-02,  4.7000e-03]]),  # torch.Size([16, 918])
        #     'item_int_feats': tensor([[  161,   893,     0,     ...,     0,     0,     0],
        #                               [   90,   518,   455,     ...,    29,   134,   873],
        #                               ...,
        #                               [    8,   431,   927,     ...,    0,     0,     0],
        #                               [   23,   669,  1303,     ...,    0,     0,     0]]), # torch.Size([16, 33])
        #     'item_dense_feats': tensor([], size=(16, 0)), 
        #     'label': tensor([0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0]),  # torch.Size([16])
        #     'timestamp': tensor([1772725140, 1772725252, 1772725278, ..., 1772725172, 1772725277, 1772725304]), # torch.Size([16])
        #     'user_id': [3864676, 8507274, 11951382, ..., 10685860, 9976196, 8037367], # 长为 16 的列表
        #     '_seq_domains': ['seq_a', 'seq_b', 'seq_c', 'seq_d'], 
        #     'seq_a': tensor([[[     0,      0,      0,  ...,      0,      0,      0],
        #                       ...,
        #                       [    12,      1,      0,  ...,     14,      0,      0]],
        #                      [[     0,      0,      0,  ...,      0,      0,      0],
        #                       ...,
        #                       [    14,      1,      1,  ...,     16,     16,      1]],
        #                      ...,
        #                      [[     0,      0,      0,  ...,      0,      0,      0],
        #                       ...,
        #                       [    12,     16,     16,  ...,      1,     14,      1]],
        #                      [[     0,      0,      0,  ...,      0,      0, 196425],
        #                       ...,
        #                       [     1,      1,     17,  ...,     16,     16,     17]]]), # torch.Size([16, 8, 256])
        #     'seq_a_len': tensor([256, 256, 203, 256, 256, 256, 102, 256, 256,  78, 256, 256,  74, 256,  256, 256]), # torch.Size([16])
        #     'seq_a_time_bucket': tensor([[42, 48, 48,  ..., 61, 61, 61],
        #                                  [33, 33, 33,  ..., 59, 59, 59],
        #                                 ...,
        #                                  [34, 42, 42,  ..., 56, 56, 56],
        #                                  [22, 22, 22,  ..., 57, 57, 57]]), # torch.Size([16, 256])
        #     'seq_b': tensor([[[       6,       22,        6,  ...,       22,       22,       22],
        #                       ...,
        #                       [       0,        0,        0,  ...,        0,        0,        0]],
        #                      [[      25,       25,       25,  ...,       24,       24,        8],
        #                       ...,
        #                       [       0,        0,        0,  ...,        0,        0,    70448]],
        #                      ...,
        #                      [[       6,       25,       25,  ...,       19,       19,       19],
        #                       ...,
        #                       [       0,        0,        0,  ...,        0,   181624,   181624]],
        #                      [[       5,        5,        1,  ...,        6,        6,        6],
        #                       ...,
        #                       [    7547,     7547,        0,  ...,   117766,     1990,    72260]]]), # torch.Size([16, 13, 256])
        #     'seq_b_len': tensor([256, 256, 250, 256, 256,   7,  53, 239, 256,  32, 256, 256,   6, 256, 256, 256]), # torch.Size([16])
        #     'seq_b_time_bucket': tensor([[32, 40, 42,  ..., 57, 57, 57],
        #                                  [54, 54, 54,  ..., 60, 60, 60],
        #                                  ...,
        #                                  [48, 48, 49,  ..., 61, 61, 61],
        #                                  [16, 16, 22,  ..., 55, 55, 55]]), # torch.Size([16, 256])
        #     'seq_c': tensor([[[      31,       31,       31,  ...,        0,        0,        0],
        #                       ...,
        #                       [       0, 80211853,        0,  ...,        0,        0,        0]],
        #                      [[      31,       31,       31,  ...,        0,        0,        0],
        #                       ...,
        #                       [41727892, 82135815, 44760703,  ...,        0,        0,        0]],
        #                      ...,
        #                      [[      31,       31,       31,  ...,        0,        0,        0],
        #                       ...,
        #                       [79110698, 54451658,        0,  ...,        0,        0,        0]],
        #                      [[      31,       14,       31,  ...,        0,        0,        0],
        #                       ...,
        #                       [14547649,        0,        0,  ...,        0,        0,        0]]]), # torch.Size([16, 11, 512])
        #     'seq_c_len': tensor([333, 303, 512, 308, 395,  83, 301, 303, 327,  83, 512, 152, 432, 365, 266, 393]), # torch.Size([16])
        #     'seq_c_time_bucket': tensor([[48, 51, 52,  ...,  0,  0,  0],
        #                                  [51, 51, 52,  ...,  0,  0,  0],
        #                                  ...,
        #                                  [54, 54, 54,  ...,  0,  0,  0],
        #                                  [21, 24, 44,  ...,  0,  0,  0]]), # torch.Size([16, 512])
        #     'seq_d': tensor([[[     3,      3,      3,  ...,      3,      3,      3],
        #                       ...,
        #                       [     2,      2,      2,  ...,      2,      2,      2]],
        #                      [[     0,      0,      0,  ...,      0,      0,      0],
        #                       ...,
        #                       [     0,      0,      0,  ...,      0,      0,      0]],
        #                      ...,
        #                      [[     3,      3,      3,  ...,      3,      3,      3],
        #                       ...,
        #                       [     2,     13,     14,  ...,      2,     14,      2]],
        #                      [[     3,      3,      3,  ...,      3,      3,      3],
        #                       ...,
        #                       [    14,      2,      2,  ...,      8,     12,      8]]]), # torch.Size([16, 9, 512])
        #     'seq_d_len': tensor([512,   0, 297, 512, 485, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512, 512]), # torch.Size([16])
        #     'seq_d_time_bucket': tensor([[24, 32, 32,  ..., 54, 54, 54],
        #                                  [ 0,  0,  0,  ...,  0,  0,  0],
        #                                  ...,
        #                                  [35, 37, 37,  ..., 52, 52, 52],
        #                                  [14, 22, 24,  ..., 54, 54, 54]]) # torch.Size([16, 512])
        # }
        return result

def get_pcvr_data(
    data_dir: str,
    schema_path: str,
    batch_size: int = 256,
    valid_ratio: float = 0.1,
    train_ratio: float = 1.0,
    num_workers: int = 16,
    buffer_batches: int = 20,
    shuffle_train: bool = True,
    seed: int = 42,
    clip_vocab: bool = True, # ?
    seq_max_lens: Optional[Dict[str, int]] = None,
    scale_dense = True,
    further_deterministic: bool = False,
    debug: bool = False, # !
    **kwargs: Any,
) -> Tuple[DataLoader, DataLoader, PCVRParquetDataset]:
    """Create train / valid DataLoaders from raw multi-column Parquet files.

    The validation split is taken as the last ``valid_ratio`` fraction of Row
    Groups (in the file order returned by ``glob``).

    Returns:
        A tuple ``(train_loader, valid_loader, train_dataset)``. The third
        element is returned so the caller can access the feature schema
        (``user_int_schema``, ``item_int_schema``, ...) needed to construct
        the model.
    """
    random.seed(seed)

    import glob as _glob
    pq_files = sorted(_glob.glob(os.path.join(data_dir, '*.parquet')))
    # pq_files: ['/Users/wangyang/Downloads/taac26/data_sample_1000/demo_1000.parquet']

    rg_info = []
    for f in pq_files:
        pf = pq.ParquetFile(f)
        for i in range(pf.metadata.num_row_groups): # pf.metadata.num_row_groups: 1
            rg_info.append((f, i, pf.metadata.row_group(i).num_rows))
    # rg_info: [('/Users/wangyang/Downloads/taac26/data_sample_1000/demo_1000.parquet', 0, 1000)]
    total_rgs = len(rg_info) # 1

    n_valid_rgs = max(1, int(total_rgs * valid_ratio))
    n_train_rgs = total_rgs - n_valid_rgs

    # ---------------------------- ! ---------------------------
    valid_start_rg = n_train_rgs
    if debug:
        n_train_rgs = 1
        valid_start_rg = 0
        logging.warning("Only one Row Group found; using it for both train and validation")
    # ---------------------------- ! ---------------------------

    # train_ratio: use only the first N% of the training Row Groups.
    if train_ratio < 1.0:
        n_train_rgs = max(1, int(n_train_rgs * train_ratio)) 
        logging.info(f"train_ratio={train_ratio}: using {n_train_rgs} train Row Groups") 

    train_rows = sum(r[2] for r in rg_info[:n_train_rgs]) # 1000
    valid_rows = sum(r[2] for r in rg_info[valid_start_rg:]) # ! # 1000

    logging.info(f"Row Group split: {n_train_rgs} train ({train_rows} rows), "
                 f"{n_valid_rgs} valid ({valid_rows} rows)")

    train_dataset = PCVRParquetDataset(
        parquet_path=data_dir,
        schema_path=schema_path,
        batch_size=batch_size,
        seq_max_lens=seq_max_lens,
        shuffle=shuffle_train,
        buffer_batches=buffer_batches,
        row_group_range=(0, n_train_rgs),
        clip_vocab=clip_vocab,
        scale_dense=scale_dense
    )

    use_cuda = torch.cuda.is_available()
    _train_kw = {}
    if num_workers > 0:
        _train_kw['persistent_workers'] = True
        _train_kw['prefetch_factor'] = 2

    def _worker_init_fn(worker_id):
        """Seed each DataLoader worker independently for reproducibility."""
        worker_seed = seed + worker_id
        np.random.seed(worker_seed)
        random.seed(worker_seed)
        torch.manual_seed(worker_seed)

    train_loader = DataLoader(
        train_dataset, batch_size=None,
        num_workers=num_workers, pin_memory=use_cuda,
        worker_init_fn=_worker_init_fn if further_deterministic else None, **_train_kw,
    )

    valid_dataset = PCVRParquetDataset(
        parquet_path=data_dir,
        schema_path=schema_path,
        batch_size=batch_size,
        seq_max_lens=seq_max_lens,
        shuffle=False,
        buffer_batches=0,
        row_group_range=(valid_start_rg, total_rgs), # !
        clip_vocab=clip_vocab,
        scale_dense=scale_dense
    )
    valid_loader = DataLoader(
        valid_dataset, batch_size=None,
        num_workers=0, pin_memory=use_cuda,
    )

    logging.info(f"Parquet train: {train_rows} rows, valid: {valid_rows} rows, "
                 f"batch_size={batch_size}, buffer_batches={buffer_batches}")

    return train_loader, valid_loader, train_dataset
