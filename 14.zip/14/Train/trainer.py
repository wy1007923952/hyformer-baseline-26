"""PCVRHyFormer pointwise trainer (binary-classification, AUC-monitored).

Despite the historical "Ranking" suffix in the class name, the training loop
uses pointwise BCE / Focal loss and evaluates Binary AUC + binary logloss.
"""

import os
import glob
import time
import shutil
import logging
from typing import Any, Dict, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from tqdm import tqdm
from sklearn.metrics import roc_auc_score

from utils import sigmoid_focal_loss, EarlyStopping
from model import ModelInput

import math

class PCVRHyFormerRankingTrainer:
    """PCVRHyFormer trainer for pointwise binary classification.

    Uses PCVR data layout:
    - user_int_feats, user_dense_feats
    - item_int_feats, item_dense_feats
    - seq_a, seq_b, seq_c, seq_d (each with *_len companion)
    - label (binary)

    Loss: BCEWithLogitsLoss or Focal Loss.
    Metrics: BinaryAUROC + binary logloss.
    """

    def __init__(
        self,
        model: nn.Module,
        train_loader: DataLoader,
        valid_loader: DataLoader,
        lr: float,
        num_epochs: int,
        device: str,
        save_dir: str,
        early_stopping: EarlyStopping,
        loss_type: str = 'bce',
        focal_alpha: float = 0.1,
        focal_gamma: float = 2.0,
        sparse_lr: float = 0.05,
        sparse_weight_decay: float = 0.0,
        reinit_sparse_after_epoch: int = 1,
        reinit_cardinality_threshold: int = 0,
        ckpt_params: Optional[Dict[str, Any]] = None,
        writer: Optional[Any] = None,
        schema_path: Optional[str] = None,
        ns_groups_path: Optional[str] = None,
        eval_every_n_steps: int = 0,
        train_config: Optional[Dict[str, Any]] = None,
        label_smooth: float = 0.0, # ！
        amp_type: Optional[str] = None, # ！ 'bf16', 'fp16', or None
        pairwise_loss_weight: float = 0.0, # ！
    ) -> None:
        self.model: nn.Module = model
        self.train_loader: DataLoader = train_loader
        self.valid_loader: DataLoader = valid_loader
        self.writer = writer
        # schema_path is copied alongside every checkpoint so that infer.py can
        # rebuild the exact same feature schema the model was trained with.
        self.schema_path: Optional[str] = schema_path
        # ns_groups_path is optional; copied next to schema.json when provided
        # and points at an existing file. Keeping the JSON inside the ckpt dir
        # makes the checkpoint self-contained for evaluation environments that
        # do not ship ns_groups.json separately.
        self.ns_groups_path: Optional[str] = ns_groups_path

        # Dual optimizer: Adagrad for sparse Embeddings, AdamW for dense params.
        self.sparse_optimizer: Optional[torch.optim.Optimizer]
        if hasattr(model, 'get_sparse_params'):
            sparse_params = model.get_sparse_params()
            dense_params = model.get_dense_params()
            sparse_param_count = sum(p.numel() for p in sparse_params)
            dense_param_count = sum(p.numel() for p in dense_params)
            logging.info(f"Sparse params: {len(sparse_params)} tensors, {sparse_param_count:,} parameters (Adagrad lr={sparse_lr})")
            logging.info(f"Dense params: {len(dense_params)} tensors, {dense_param_count:,} parameters (AdamW lr={lr})")
            self.sparse_optimizer = torch.optim.Adagrad(
                sparse_params, lr=sparse_lr, weight_decay=sparse_weight_decay
            )
            self.dense_optimizer: torch.optim.Optimizer = torch.optim.AdamW(
                dense_params, lr=lr, betas=(0.9, 0.98)
            )
        else:
            self.sparse_optimizer = None
            self.dense_optimizer = torch.optim.AdamW(
                model.parameters(), lr=lr, betas=(0.9, 0.98)
            )

        self.num_epochs: int = num_epochs
        self.device: str = device
        self.save_dir: str = save_dir
        self.early_stopping: EarlyStopping = early_stopping
        self.loss_type: str = loss_type
        self.focal_alpha: float = focal_alpha
        self.focal_gamma: float = focal_gamma
        self.reinit_sparse_after_epoch: int = reinit_sparse_after_epoch
        self.reinit_cardinality_threshold: int = reinit_cardinality_threshold
        self.sparse_lr: float = sparse_lr
        self.sparse_weight_decay: float = sparse_weight_decay
        self.ckpt_params: Dict[str, Any] = ckpt_params or {}
        self.eval_every_n_steps: int = eval_every_n_steps
        self.train_config: Optional[Dict[str, Any]] = train_config

        self.label_smooth = label_smooth # ！
        self.amp_type = amp_type # ！
        self.pairwise_loss_weight = pairwise_loss_weight # ！
        
        # Resolve autocast dtype and whether GradScaler is needed
        self._amp_enabled = amp_type is not None
        if amp_type == 'bf16':
            self._amp_torch_dtype = torch.bfloat16
            self._grad_scaler = None  # BF16 does not need GradScaler
        elif amp_type == 'fp16':
            self._amp_torch_dtype = torch.float16
            self._grad_scaler = torch.amp.GradScaler('cuda')  # FP16 needs GradScaler
        else:
            self._amp_torch_dtype = torch.float32  # unused when disabled
            self._grad_scaler = None

        logging.info(f"PCVRHyFormerRankingTrainer loss_type={loss_type}, "
                     f"focal_alpha={focal_alpha}, focal_gamma={focal_gamma}, "
                     f"reinit_sparse_after_epoch={reinit_sparse_after_epoch}, "
                     f"amp_type={amp_type}, "
                     f"pairwise_loss_weight={pairwise_loss_weight}")

    def _build_step_dir_name(self, global_step: int, is_best: bool = False) -> str:
        """Build a checkpoint sub-directory name such as
        ``global_step2500.layer=2.head=4.hidden=64[.best_model]``.
        """
        parts = [f"global_step{global_step}"]
        for key in ("layer", "head", "hidden"):
            if key in self.ckpt_params:
                parts.append(f"{key}={self.ckpt_params[key]}")
        name = ".".join(parts)
        if is_best:
            name += ".best_model"
        return name

    def _write_sidecar_files(self, ckpt_dir: str) -> None:
        """Write sidecar files next to a ``model.pt``.

        Currently persists up to three files, all overwritten on every call:

        - ``schema.json`` (copied from ``self.schema_path``): feature layout
          metadata needed to rebuild the Parquet dataset.
        - ``ns_groups.json`` (copied from ``self.ns_groups_path`` when set
          and the file exists): NS-token grouping used to construct the
          tokenizer. Making a per-ckpt copy lets evaluation environments
          consume the checkpoint without having to ship the original
          project-level ``ns_groups.json``.
        - ``train_config.json`` (serialized from ``self.train_config``):
          full set of training-time hyperparameters. When ``ns_groups.json``
          is copied into ``ckpt_dir``, the ``ns_groups_json`` field is
          rewritten to the bare filename so that ``infer.py`` resolves it
          against ``ckpt_dir`` rather than the original absolute path on
          the training machine.
        """
        os.makedirs(ckpt_dir, exist_ok=True)
        if self.schema_path and os.path.exists(self.schema_path):
            shutil.copy2(self.schema_path, ckpt_dir)

        ns_groups_copied = False
        if self.ns_groups_path and os.path.exists(self.ns_groups_path):
            shutil.copy2(self.ns_groups_path, ckpt_dir)
            ns_groups_copied = True

        # self.train_config: 跟train.py中的 vars(args) 完全一致
        # {
        #     'data_dir': '/Users/wangyang/Downloads/taac26/data_sample_1000', 
        #     'schema_path': '/Users/wangyang/Downloads/taac26/data_sample_1000/schema.json', 
        #     'ckpt_dir': '/Users/wangyang/Downloads/taac26/outputs/local_ckpt', 
        #     'log_dir': '/Users/wangyang/Downloads/taac26/outputs/local_logs', 
        #     'batch_size': 16, 
        #     'lr': 0.0001, 
        #     'num_epochs': 999, 
        #     'patience': 5, 
        #     'seed': 42, 
        #     'device': 'cpu', 
        #     'num_workers': 0, 
        #     'buffer_batches': 20, 
        #     'train_ratio': 1.0, 
        #     'valid_ratio': 0.1, 
        #     'eval_every_n_steps': 0, 
        #     'seq_max_lens': 'seq_a:256,seq_b:256,seq_c:512,seq_d:512', 
        #     'd_model': 64, 
        #     'emb_dim': 64, 
        #     'num_queries': 2, 
        #     'num_hyformer_blocks': 2, 
        #     'num_heads': 4, 
        #     'seq_encoder_type': 'transformer', 
        #     'hidden_mult': 4, 
        #     'dropout_rate': 0.01, 
        #     'seq_top_k': 50, 
        #     'seq_causal': False, 
        #     'action_num': 1, 
        #     'use_time_buckets': True, 
        #     'rank_mixer_mode': 'full', 
        #     'use_rope': False, 
        #     'rope_base': 10000.0, 
        #     'loss_type': 'bce', 
        #     'focal_alpha': 0.1, 
        #     'focal_gamma': 2.0, 
        #     'sparse_lr': 0.05, 
        #     'sparse_weight_decay': 0.0, 
        #     'reinit_sparse_after_epoch': 1, 
        #     'reinit_cardinality_threshold': 0, 
        #     'emb_skip_threshold': 1000000, 
        #     'seq_id_threshold': 10000, 
        #     'ns_groups_json': '', 
        #     'ns_tokenizer_type': 'rankmixer', 
        #     'user_ns_tokens': 5, 
        #     'item_ns_tokens': 2, 
        #     'debug': True, 
        #     'tf_events_dir': '/Users/wangyang/Downloads/taac26/outputs/local_tb'
        # }
        if self.train_config:
            import json
            cfg_to_dump = self.train_config
            if ns_groups_copied:
                # Override the stored path to a filename relative to ckpt_dir;
                # infer.py already falls back to `<ckpt_dir>/<basename>` when
                # the recorded path is not absolute, which keeps the ckpt
                # portable across hosts.
                cfg_to_dump = dict(self.train_config)
                cfg_to_dump['ns_groups_json'] = os.path.basename(
                    self.ns_groups_path)
            with open(os.path.join(ckpt_dir, 'train_config.json'), 'w') as f:
                json.dump(cfg_to_dump, f, indent=2)

    def _save_step_checkpoint(
        self,
        global_step: int,
        is_best: bool = False,
        skip_model_file: bool = False,
    ) -> str:
        """Save ``model.pt`` plus sidecar files under a ``global_step`` sub-dir.

        Args:
            global_step: current global step used to name the directory.
            is_best: whether this is a new-best checkpoint.
            skip_model_file: if True, skip writing ``model.pt`` (because the
                caller, e.g. EarlyStopping, has already persisted it to the
                same path). Sidecar files are still (re)written.

        Returns:
            The absolute path of the checkpoint directory.
        """
        dir_name = self._build_step_dir_name(global_step, is_best=is_best)
        ckpt_dir = os.path.join(self.save_dir, dir_name)
        os.makedirs(ckpt_dir, exist_ok=True)
        if not skip_model_file:
            torch.save(self.model.state_dict(), os.path.join(ckpt_dir, "model.pt"))
        self._write_sidecar_files(ckpt_dir)
        logging.info(f"Saved checkpoint to {ckpt_dir}/model.pt")
        return ckpt_dir

    def _remove_old_best_dirs(self) -> None:
        """Delete stale ``*.best_model`` directories so that only the latest
        best checkpoint is kept on disk.
        """
        pattern = os.path.join(self.save_dir, "global_step*.best_model")
        for old_dir in glob.glob(pattern):
            shutil.rmtree(old_dir)
            logging.info(f"Removed old best_model dir: {old_dir}")

    def _batch_to_device(self, batch: Dict[str, Any]) -> Dict[str, Any]:
        """Move all tensors in ``batch`` to ``self.device`` (``non_blocking=True``,
        to cooperate with ``pin_memory``). Non-tensor values pass through.
        """
        device_batch: Dict[str, Any] = {}
        for k, v in batch.items():
            if isinstance(v, torch.Tensor):
                device_batch[k] = v.to(self.device, non_blocking=True)
            else:
                device_batch[k] = v
        return device_batch

    def _handle_validation_result(
        self,
        total_step: int,
        val_auc: float,
        val_logloss: float,
    ) -> None:
        """Persist a new-best checkpoint atomically.

        Flow (ordered to avoid leaving empty sidecar-only directories on disk):

        1. Decide whether ``val_auc`` is *likely* to beat the current best
           using the same threshold as ``EarlyStopping._is_not_improved``,
           so our pre-cleanup and EarlyStopping's internal save decision
           stay in sync.
        2. If unlikely, short-circuit: do nothing on disk. We must NOT
           touch ``self.early_stopping.checkpoint_path`` or call
           ``_write_sidecar_files`` because the target directory may not
           exist yet (sidecar-only dirs would otherwise be created here,
           producing checkpoints with missing ``model.pt``).
        3. If likely, point ``EarlyStopping`` at the canonical
           ``global_stepN.best_model/model.pt`` path, remove any stale
           ``*.best_model`` dirs, then run ``EarlyStopping`` (which writes
           ``model.pt`` when it actually confirms a new best).
        4. Only after ``EarlyStopping`` has confirmed a new best
           (``best_score != old_best``) do we write the sidecar files into
           the freshly-created directory; this is guarded so that a
           razor-close score that tripped ``is_likely_new_best`` but not
           ``EarlyStopping``'s own gate does not create a stray dir.
        """
        old_best = self.early_stopping.best_score
        is_likely_new_best = (
            old_best is None
            or val_auc > old_best + self.early_stopping.delta
        )
        if not is_likely_new_best:
            # No new best anticipated: leave disk untouched. The previous
            # best_model dir (with its model.pt + sidecars) remains valid.
            self.early_stopping(val_auc, self.model, {
                "best_val_AUC": val_auc,
                "best_val_logloss": val_logloss,
            })
            return

        # Point EarlyStopping at the canonical best-model location for this
        # step. Only done on the likely-new-best branch so that a skipped
        # save never leaks the unused path into EarlyStopping state.
        best_dir = os.path.join(
            self.save_dir,
            self._build_step_dir_name(total_step, is_best=True),
        )
        self.early_stopping.checkpoint_path = os.path.join(best_dir, "model.pt")

        # Remove stale best dirs first so EarlyStopping's write is the only
        # I/O needed when a new best is confirmed.
        self._remove_old_best_dirs()

        self.early_stopping(val_auc, self.model, {
            "best_val_AUC": val_auc,
            "best_val_logloss": val_logloss,
        })

        # Write sidecar files only when EarlyStopping actually confirmed a
        # new best and wrote model.pt. If the score tripped our heuristic
        # but EarlyStopping internally declined to save, skip to avoid
        # creating an empty (sidecar-only) checkpoint directory.
        if self.early_stopping.best_score != old_best and os.path.exists(
            self.early_stopping.checkpoint_path
        ):
            self._save_step_checkpoint(
                total_step, is_best=True, skip_model_file=True)

    def train(self) -> None:
        """Main training loop: iterates over epochs, performs step-level and
        epoch-level validation, triggers EarlyStopping and the periodic sparse
        re-initialization strategy.
        """
        print("Start training (PCVRHyFormer)")
        self.model.train()
        total_step = 0

        for epoch in range(1, self.num_epochs + 1): # range(1, 1000)
            train_pbar = tqdm(enumerate(self.train_loader), total=len(self.train_loader),
                              dynamic_ncols=True) # total = 63
            loss_sum = 0.0
            epoch_start_time = time.time()

            for step, batch in train_pbar:
                # step 如 0, batch 如
                # {
                #     'user_int_feats': tensor([[  2, 674, 280,  ...,   2,   0,   0],
                #                               [  4, 645, 630,  ...,   1,   0,   0],
                #                               ...,
                #                               [  4, 198, 944,  ...,   0,   0,   0],
                #                               [  4, 325, 134,  ...,   0,   6,   0]]), # torch.Size([16, 411])
                #     'user_dense_feats': tensor([[ 0.1255,  0.0436,  0.1064,  ...,  0.3563,  0.0737,  0.0103],
                #                                 [ 0.1208,  0.0142,  0.0888,  ..., -0.0901, -0.0133, -0.0015],
                #                                 ...,
                #                                 [ 0.1256,  0.0999,  0.0869,  ...,  0.0000,  0.0000,  0.0000],
                #                                 [ 0.1192,  0.0688,  0.0735,  ...,  0.0000,  0.0000,  0.0000]]), # torch.Size([16, 918])
                #     'item_int_feats': tensor([[  146,   317,  2158,  ...,   0,     0,     0],
                #                               [    8,   431,   927,  ...,   0,     0,     0],
                #                               ...,
                #                               [   90,   242,   261,  ...,   8,     9,   474],
                #                               [  279,   752,  1593,  ...,   0,     0,     0]]), # torch.Size([16, 33])
                #     'item_dense_feats': tensor([], size=(16, 0)), 
                #     'label': tensor([0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0]),  # torch.Size([16])
                #     'timestamp': tensor([1772725036, 1772725277, ..., 1772725162, 1772725530]),  # torch.Size([16])
                #     'seq_a': tensor([[[     0,      0,      0,  ...,      0,      0,      0],
                #                       ...,
                #                       [     1,      1,     16,  ...,      1,      1,     14]],
                #                      [[     0,      0,      0,  ...,      0,      0,      0],
                #                       ...,
                #                       [    12,     16,     16,  ...,      1,     14,      1]],
                #                      ...,
                #                      [[     0,      0,      0,  ...,      0,      0,      0],
                #                       ...,
                #                       [     2,     14,      2,  ...,      0,      0,      0]],
                #                      [[     0,      0,      0,  ...,      0,      0,      0],
                #                       ...,
                #                       [    12,      0,      0,  ...,      0,      0,      0]]]),  # torch.Size([16, 8, 256])
                #     'seq_a_len': tensor([256, 256, 256, ...,  256,  169,  58]),  # torch.Size([16])
                #     'seq_a_time_bucket': tensor([[33, 34, 34,  ..., 58, 58, 58],
                #                                  [34, 42, 42,  ..., 56, 56, 56],
                #                                  ...,
                #                                  [47, 47, 47,  ...,  0,  0,  0],
                #                                  [54, 54, 54,  ...,  0,  0,  0]]), # torch.Size([16, 256])
                #     'seq_b': tensor([[[       6,       14,        3,  ...,        6,       25,        6],
                #                       ...,
                #                       [       0,        0,        0,  ...,   185332,        0,      370]],
                #                      [[       6,       25,       25,  ...,       19,       19,       19],
                #                       ...,
                #                       [       0,        0,        0,  ...,        0,   181624,   181624]],
                #                      ...,
                #                      [[      25,        6,        6,  ...,        0,        0,        0],
                #                       ...,
                #                       [       0,   141137,    53066,  ...,        0,        0,        0]],
                #                      [[      22,       22,       20,  ...,        0,        0,        0],
                #                       ...,
                #                       [       0,        0,        0,  ...,        0,        0,        0]]]), # torch.Size([16, 13, 256])
                #     'seq_b_len': tensor([256, 256, 256, ..., 256,  118,  42]),  # torch.Size([16])
                #     'seq_b_time_bucket': tensor([[24, 34, 34,  ..., 54, 54, 54],
                #                                  [48, 48, 49,  ..., 61, 61, 61],
                #                                  ...,
                #                                  [47, 49, 49,  ...,  0,  0,  0],
                #                                  [56, 56, 61,  ...,  0,  0,  0]]), # torch.Size([16, 256])
                #     'seq_c': tensor([[[      10,       31,       36,  ...,       36,       10,       31],
                #                       ...,
                #                       [       0,        0, 44341152,  ...,        0, 83219569, 83219569]],
                #                      [[      31,       31,       31,  ...,        0,        0,        0],
                #                       ...,
                #                       [79110698, 54451658,        0,  ...,        0,        0,        0]],
                #                      ...,
                #                      [[      31,       31,       31,  ...,        0,        0,        0],
                #                       ...,
                #                       [49695077, 49695077,        0,  ...,        0,        0,        0]],
                #                      [[      42,       31,       31,  ...,        0,        0,        0],
                #                       ...,
                #                       [47959838, 47959838, 47959838,  ...,        0,        0,        0]]]),  # torch.Size([16, 11, 512])
                #     'seq_c_len': tensor([512, 266, 512, ..., 379, 266, 445]), # torch.Size([16])
                #     'seq_c_time_bucket': tensor([[42, 42, 49,  ..., 63, 63, 63],
                #                                  [54, 54, 54,  ...,  0,  0,  0],
                #                                  ...,
                #                                  [47, 47, 47,  ...,  0,  0,  0],
                #                                  [49, 50, 50,  ...,  0,  0,  0]]), # torch.Size([16, 512])
                #     'seq_d': tensor([[[     3,      3,      3,  ...,      0,      0,      0],
                #                       ...,
                #                       [     2,      2,      2,  ...,      0,      0,      0]],
                #                      [[     3,      3,      3,  ...,      3,      3,      3],
                #                       ...,
                #                       [     2,     13,     14,  ...,      2,     14,      2]],
                #                      ...,
                #                      [[     3,      3,      3,  ...,      3,      3,      3],
                #                       ...,
                #                       [    12,      2,     14,  ...,     10,     10,     13]],
                #                      [[     3,      3,      3,  ...,      3,      3,      3],
                #                       ...,
                #                       [     8,     13,     12,  ...,      2,      2,      2]]]), # torch.Size([16, 9, 512])
                #     'seq_d_len': tensor([322, 512, 512, ..., 512, 512, 512]), # torch.Size([16])
                #     'seq_d_time_bucket': tensor([[48, 48, 48,  ...,  0,  0,  0],
                #                                  [35, 37, 37,  ..., 52, 52, 52],
                #                                  ...,
                #                                  [47, 47, 47,  ..., 54, 54, 54],
                #                                  [13, 16, 16,  ..., 53, 53, 53]]), # torch.Size([16, 512])
                #     'user_id': [3864676, 8507274, 11951382, ..., 10685860, 9976196, 8037367],  # 长为 16 的列表
                #     '_seq_domains': ['seq_a', 'seq_b', 'seq_c', 'seq_d']
                # }
                loss, mean_pos_p, mean_neg_p, grad_norm_before, grad_norm_after, current_dense_lr, current_sparse_lr, pointwise_loss_item, pairwise_loss_item = self._train_step(batch) # ! # 0.1576574295759201, 0.5089883208274841, 0.5048762559890747, 5.397327205176909, 0.9999997783878847
                total_step += 1
                loss_sum += loss

                if self.writer:
                    self.writer.add_scalar('Loss/total', loss, total_step)
                    self.writer.add_scalar('Loss/pointwise', pointwise_loss_item, total_step)
                    if pairwise_loss_item > 0:
                        self.writer.add_scalar('Loss/pairwise', pairwise_loss_item, total_step)
                    if math.isnan(mean_pos_p) or math.isnan(mean_neg_p):  # !
                        pass
                    else:
                        self.writer.add_scalar("Model/pos_p", mean_pos_p, total_step) # ！
                        self.writer.add_scalar("Model/neg_p", mean_neg_p, total_step) # ！
                    self.writer.add_scalar('Analyse/grad_norm_before', grad_norm_before, total_step) # ！
                    self.writer.add_scalar('Analyse/grad_norm_after', grad_norm_after, total_step) # ！
                    self.writer.add_scalar('Analyse/dense_learning_date', current_dense_lr, total_step) # ！
                    self.writer.add_scalar('Analyse/sparse_learning_date', current_sparse_lr, total_step) # ！

                train_pbar.set_postfix({"loss": f"{loss:.4f}"})

                # 每 500 步估算一个 epoch 的耗时
                if (step + 1) % 500 == 0:
                    elapsed = time.time() - epoch_start_time
                    steps_done = step + 1
                    avg_it_s = steps_done / elapsed
                    total = len(self.train_loader)
                    eta = total / avg_it_s
                    logging.info(f"Epoch {epoch} step {steps_done}/{total} | "
                                f"loss={loss:.6f} pos={mean_pos_p:.4f} neg={mean_neg_p:.4f} | "
                                f"elapsed={elapsed:.0f}s ETA={eta:.0f}s | "
                                f"{avg_it_s:.2f} it/s")

                # Step-level validation (only when eval_every_n_steps > 0).
                if self.eval_every_n_steps > 0 and total_step % self.eval_every_n_steps == 0:
                    logging.info(f"Evaluating at step {total_step}")
                    val_auc, val_logloss = self.evaluate(epoch=epoch)
                    self.model.train()
                    torch.cuda.empty_cache()

                    logging.info(f"Step {total_step} Validation | AUC: {val_auc}, LogLoss: {val_logloss}")

                    if self.writer:
                        self.writer.add_scalar('AUC/valid', val_auc, total_step)
                        self.writer.add_scalar('LogLoss/valid', val_logloss, total_step)

                    self._handle_validation_result(total_step, val_auc, val_logloss)

                    if self.early_stopping.early_stop:
                        logging.info(f"Early stopping at step {total_step}")
                        return

            logging.info(f"Epoch {epoch}, Average Loss: {loss_sum / len(self.train_loader)}")

            val_auc, val_logloss = self.evaluate(epoch=epoch)
            self.model.train()
            torch.cuda.empty_cache()

            logging.info(f"Epoch {epoch} Validation | AUC: {val_auc}, LogLoss: {val_logloss}")

            if self.writer:
                self.writer.add_scalar('AUC/valid', val_auc, total_step)
                self.writer.add_scalar('LogLoss/valid', val_logloss, total_step)

            self._handle_validation_result(total_step, val_auc, val_logloss)

            if self.early_stopping.early_stop:
                logging.info(f"Early stopping at epoch {epoch}")
                break

            # After the configured epoch, reinitialize high-cardinality sparse
            # params (Embeddings) as a form of cold restart to reduce overfit.
            # Reference: KuaiShou Tech., "MultiEpoch: Reusing Training Data
            # for Click-Through Rate Prediction",
            # https://arxiv.org/pdf/2305.19531
            if epoch >= self.reinit_sparse_after_epoch and self.sparse_optimizer is not None:
                # Snapshot Adagrad state per parameter via data_ptr, so state
                # of low-cardinality embeddings can be preserved across rebuild.
                old_state: Dict[int, Any] = {}
                for group in self.sparse_optimizer.param_groups:
                    for p in group['params']:
                        if p.data_ptr() in self.sparse_optimizer.state:
                            old_state[p.data_ptr()] = self.sparse_optimizer.state[p]

                reinit_ptrs = self.model.reinit_high_cardinality_params(self.reinit_cardinality_threshold)
                sparse_params = self.model.get_sparse_params()
                self.sparse_optimizer = torch.optim.Adagrad(
                    sparse_params, lr=self.sparse_lr, weight_decay=self.sparse_weight_decay
                )
                # Restore optimizer state for low-cardinality embeddings only.
                restored = 0
                for p in sparse_params:
                    if p.data_ptr() not in reinit_ptrs and p.data_ptr() in old_state:
                        self.sparse_optimizer.state[p] = old_state[p.data_ptr()]
                        restored += 1
                logging.info(f"Rebuilt Adagrad optimizer after epoch {epoch}, "
                             f"restored optimizer state for {restored} low-cardinality params")

    def _make_model_input(self, device_batch: Dict[str, Any]) -> ModelInput:
        """Construct a ``ModelInput`` NamedTuple from a device_batch dict."""
        # {
        #     'user_int_feats': tensor([[  2, 674, 280,  ...,   2,   0,   0],
        #                               [  4, 645, 630,  ...,   1,   0,   0],
        #                               ...,
        #                               [  4, 198, 944,  ...,   0,   0,   0],
        #                               [  4, 325, 134,  ...,   0,   6,   0]]), # torch.Size([16, 411])
        #     'user_dense_feats': tensor([[ 0.1255,  0.0436,  0.1064,  ...,  0.3563,  0.0737,  0.0103],
        #                                 [ 0.1208,  0.0142,  0.0888,  ..., -0.0901, -0.0133, -0.0015],
        #                                 ...,
        #                                 [ 0.1256,  0.0999,  0.0869,  ...,  0.0000,  0.0000,  0.0000],
        #                                 [ 0.1192,  0.0688,  0.0735,  ...,  0.0000,  0.0000,  0.0000]]), # torch.Size([16, 918])
        #     'item_int_feats': tensor([[  146,   317,  2158,  ...,   0,     0,     0],
        #                               [    8,   431,   927,  ...,   0,     0,     0],
        #                               ...,
        #                               [   90,   242,   261,  ...,   8,     9,   474],
        #                               [  279,   752,  1593,  ...,   0,     0,     0]]), # torch.Size([16, 33])
        #     'item_dense_feats': tensor([], size=(16, 0)), 
        #     'label': tensor([0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0]),  # torch.Size([16])
        #     'timestamp': tensor([1772725036, 1772725277, ..., 1772725162, 1772725530]),  # torch.Size([16])
        #     'seq_a': tensor([[[     0,      0,      0,  ...,      0,      0,      0],
        #                       ...,
        #                       [     1,      1,     16,  ...,      1,      1,     14]],
        #                      [[     0,      0,      0,  ...,      0,      0,      0],
        #                       ...,
        #                       [    12,     16,     16,  ...,      1,     14,      1]],
        #                      ...,
        #                      [[     0,      0,      0,  ...,      0,      0,      0],
        #                       ...,
        #                       [     2,     14,      2,  ...,      0,      0,      0]],
        #                      [[     0,      0,      0,  ...,      0,      0,      0],
        #                       ...,
        #                       [    12,      0,      0,  ...,      0,      0,      0]]]),  # torch.Size([16, 8, 256])
        #     'seq_a_len': tensor([256, 256, 256, ...,  256,  169,  58]),  # torch.Size([16])
        #     'seq_a_time_bucket': tensor([[33, 34, 34,  ..., 58, 58, 58],
        #                                  [34, 42, 42,  ..., 56, 56, 56],
        #                                  ...,
        #                                  [47, 47, 47,  ...,  0,  0,  0],
        #                                  [54, 54, 54,  ...,  0,  0,  0]]), # torch.Size([16, 256])
        #     'seq_b': tensor([[[       6,       14,        3,  ...,        6,       25,        6],
        #                       ...,
        #                       [       0,        0,        0,  ...,   185332,        0,      370]],
        #                      [[       6,       25,       25,  ...,       19,       19,       19],
        #                       ...,
        #                       [       0,        0,        0,  ...,        0,   181624,   181624]],
        #                      ...,
        #                      [[      25,        6,        6,  ...,        0,        0,        0],
        #                       ...,
        #                       [       0,   141137,    53066,  ...,        0,        0,        0]],
        #                      [[      22,       22,       20,  ...,        0,        0,        0],
        #                       ...,
        #                       [       0,        0,        0,  ...,        0,        0,        0]]]), # torch.Size([16, 13, 256])
        #     'seq_b_len': tensor([256, 256, 256, ..., 256,  118,  42]),  # torch.Size([16])
        #     'seq_b_time_bucket': tensor([[24, 34, 34,  ..., 54, 54, 54],
        #                                  [48, 48, 49,  ..., 61, 61, 61],
        #                                  ...,
        #                                  [47, 49, 49,  ...,  0,  0,  0],
        #                                  [56, 56, 61,  ...,  0,  0,  0]]), # torch.Size([16, 256])
        #     'seq_c': tensor([[[      10,       31,       36,  ...,       36,       10,       31],
        #                       ...,
        #                       [       0,        0, 44341152,  ...,        0, 83219569, 83219569]],
        #                      [[      31,       31,       31,  ...,        0,        0,        0],
        #                       ...,
        #                       [79110698, 54451658,        0,  ...,        0,        0,        0]],
        #                      ...,
        #                      [[      31,       31,       31,  ...,        0,        0,        0],
        #                       ...,
        #                       [49695077, 49695077,        0,  ...,        0,        0,        0]],
        #                      [[      42,       31,       31,  ...,        0,        0,        0],
        #                       ...,
        #                       [47959838, 47959838, 47959838,  ...,        0,        0,        0]]]),  # torch.Size([16, 11, 512])
        #     'seq_c_len': tensor([512, 266, 512, ..., 379, 266, 445]), # torch.Size([16])
        #     'seq_c_time_bucket': tensor([[42, 42, 49,  ..., 63, 63, 63],
        #                                  [54, 54, 54,  ...,  0,  0,  0],
        #                                  ...,
        #                                  [47, 47, 47,  ...,  0,  0,  0],
        #                                  [49, 50, 50,  ...,  0,  0,  0]]), # torch.Size([16, 512])
        #     'seq_d': tensor([[[     3,      3,      3,  ...,      0,      0,      0],
        #                       ...,
        #                       [     2,      2,      2,  ...,      0,      0,      0]],
        #                      [[     3,      3,      3,  ...,      3,      3,      3],
        #                       ...,
        #                       [     2,     13,     14,  ...,      2,     14,      2]],
        #                      ...,
        #                      [[     3,      3,      3,  ...,      3,      3,      3],
        #                       ...,
        #                       [    12,      2,     14,  ...,     10,     10,     13]],
        #                      [[     3,      3,      3,  ...,      3,      3,      3],
        #                       ...,
        #                       [     8,     13,     12,  ...,      2,      2,      2]]]), # torch.Size([16, 9, 512])
        #     'seq_d_len': tensor([322, 512, 512, ..., 512, 512, 512]), # torch.Size([16])
        #     'seq_d_time_bucket': tensor([[48, 48, 48,  ...,  0,  0,  0],
        #                                  [35, 37, 37,  ..., 52, 52, 52],
        #                                  ...,
        #                                  [47, 47, 47,  ..., 54, 54, 54],
        #                                  [13, 16, 16,  ..., 53, 53, 53]]), # torch.Size([16, 512])
        #     'user_id': [3864676, 8507274, 11951382, ..., 10685860, 9976196, 8037367],  # 长为 16 的列表
        #     '_seq_domains': ['seq_a', 'seq_b', 'seq_c', 'seq_d']
        # }
        seq_domains = device_batch['_seq_domains'] # ['seq_a', 'seq_b', 'seq_c', 'seq_d']
        seq_data: Dict[str, torch.Tensor] = {}
        seq_lens: Dict[str, torch.Tensor] = {}
        seq_time_buckets: Dict[str, torch.Tensor] = {}
        for domain in seq_domains:
            seq_data[domain] = device_batch[domain] # 如 torch.Size([16, 8, 256])
            seq_lens[domain] = device_batch[f'{domain}_len'] # 如 torch.Size([16])
            # tensor([256, 256, 256, 153,  68, 256, 256, 256, 256, 256,  13, 256, 256, 256, 169,  58])
            B = device_batch[domain].shape[0] # 16
            L = device_batch[domain].shape[2] # 256
            seq_time_buckets[domain] = device_batch.get(
                f'{domain}_time_bucket',
                torch.zeros(B, L, dtype=torch.long, device=self.device)) # torch.Size([16, 256])
        # seq_data:
        # {
        #     'seq_a': tensor([[[     0,      0,      0,  ...,      0,      0,      0],
        #                       ...,
        #                       [     1,      1,     16,  ...,      1,      1,     14]],
        #                      [[     0,      0,      0,  ...,      0,      0,      0],
        #                       ...,
        #                       [    12,     16,     16,  ...,      1,     14,      1]],
        #                      ...,
        #                      [[     0,      0,      0,  ...,      0,      0,      0],
        #                       ...,
        #                       [     2,     14,      2,  ...,      0,      0,      0]],
        #                      [[     0,      0,      0,  ...,      0,      0,      0],
        #                       ...,
        #                       [    12,      0,      0,  ...,      0,      0,      0]]]),  # torch.Size([16, 8, 256])
        #     'seq_b': tensor([[[       6,       14,        3,  ...,        6,       25,        6],
        #                       ...,
        #                       [       0,        0,        0,  ...,   185332,        0,      370]],
        #                      [[       6,       25,       25,  ...,       19,       19,       19],
        #                       ...,
        #                       [       0,        0,        0,  ...,        0,   181624,   181624]],
        #                      ...,
        #                      [[      25,        6,        6,  ...,        0,        0,        0],
        #                       ...,
        #                       [       0,   141137,    53066,  ...,        0,        0,        0]],
        #                      [[      22,       22,       20,  ...,        0,        0,        0],
        #                       ...,
        #                       [       0,        0,        0,  ...,        0,        0,        0]]]), # torch.Size([16, 13, 256])
        #     'seq_c': tensor([[[      10,       31,       36,  ...,       36,       10,       31],
        #                       ...,
        #                       [       0,        0, 44341152,  ...,        0, 83219569, 83219569]],
        #                      [[      31,       31,       31,  ...,        0,        0,        0],
        #                       ...,
        #                       [79110698, 54451658,        0,  ...,        0,        0,        0]],
        #                      ...,
        #                      [[      31,       31,       31,  ...,        0,        0,        0],
        #                       ...,
        #                       [49695077, 49695077,        0,  ...,        0,        0,        0]],
        #                      [[      42,       31,       31,  ...,        0,        0,        0],
        #                       ...,
        #                       [47959838, 47959838, 47959838,  ...,        0,        0,        0]]]),  # torch.Size([16, 11, 512])
        #     'seq_d': tensor([[[     3,      3,      3,  ...,      0,      0,      0],
        #                       ...,
        #                       [     2,      2,      2,  ...,      0,      0,      0]],
        #                      [[     3,      3,      3,  ...,      3,      3,      3],
        #                       ...,
        #                       [     2,     13,     14,  ...,      2,     14,      2]],
        #                      ...,
        #                      [[     3,      3,      3,  ...,      3,      3,      3],
        #                       ...,
        #                       [    12,      2,     14,  ...,     10,     10,     13]],
        #                      [[     3,      3,      3,  ...,      3,      3,      3],
        #                       ...,
        #                       [     8,     13,     12,  ...,      2,      2,      2]]]), # torch.Size([16, 9, 512])
        # }

        # seq_lens:
        # {
        #     'seq_a': tensor([256, 256, 256, ...,  256,  169,  58]),  # torch.Size([16])
        #     'seq_b': tensor([256, 256, 256, ..., 256,  118,  42]),  # torch.Size([16])
        #     'seq_c': tensor([512, 266, 512, ..., 379, 266, 445]), # torch.Size([16])
        #     'seq_d': tensor([322, 512, 512, ..., 512, 512, 512]), # torch.Size([16])
        # }

        # seq_time_buckets:
        # {
        #     'seq_a': tensor([[33, 34, 34,  ..., 58, 58, 58],
        #                                  [34, 42, 42,  ..., 56, 56, 56],
        #                                  ...,
        #                                  [47, 47, 47,  ...,  0,  0,  0],
        #                                  [54, 54, 54,  ...,  0,  0,  0]]), # torch.Size([16, 256])
        #     'seq_b': tensor([[24, 34, 34,  ..., 54, 54, 54],
        #                                  [48, 48, 49,  ..., 61, 61, 61],
        #                                  ...,
        #                                  [47, 49, 49,  ...,  0,  0,  0],
        #                                  [56, 56, 61,  ...,  0,  0,  0]]), # torch.Size([16, 256])
        #     'seq_c': tensor([[42, 42, 49,  ..., 63, 63, 63],
        #                                  [54, 54, 54,  ...,  0,  0,  0],
        #                                  ...,
        #                                  [47, 47, 47,  ...,  0,  0,  0],
        #                                  [49, 50, 50,  ...,  0,  0,  0]]), # torch.Size([16, 512])
        #     'seq_d': tensor([[48, 48, 48,  ...,  0,  0,  0],
        #                                  [35, 37, 37,  ..., 52, 52, 52],
        #                                  ...,
        #                                  [47, 47, 47,  ..., 54, 54, 54],
        #                                  [13, 16, 16,  ..., 53, 53, 53]]), # torch.Size([16, 512])
        # }

        # 'label',  'timestamp',  'user_id', '_seq_domains' 未加入 ModelInput 中！
        return ModelInput(
            user_int_feats=device_batch['user_int_feats'],
            item_int_feats=device_batch['item_int_feats'],
            user_dense_feats=device_batch['user_dense_feats'],
            item_dense_feats=device_batch['item_dense_feats'],
            seq_data=seq_data,
            seq_lens=seq_lens,
            seq_time_buckets=seq_time_buckets,
        )

    def _train_step(self, batch: Dict[str, Any]) -> float:
        """Run a single training step and return the scalar loss value."""
        device_batch = self._batch_to_device(batch)
        label = device_batch['label'].float() # torch.Size([16])

        self.dense_optimizer.zero_grad()
        if self.sparse_optimizer is not None:
            self.sparse_optimizer.zero_grad()

        # AMP autocast context
        autocast_ctx = torch.autocast(device_type='cuda', dtype=self._amp_torch_dtype, enabled=self._amp_enabled) # !
        # device_batch:
        # {
        #     'user_int_feats': tensor([[  2, 674, 280,  ...,   2,   0,   0],
        #                               [  4, 645, 630,  ...,   1,   0,   0],
        #                               ...,
        #                               [  4, 198, 944,  ...,   0,   0,   0],
        #                               [  4, 325, 134,  ...,   0,   6,   0]]), # torch.Size([16, 411])
        #     'user_dense_feats': tensor([[ 0.1255,  0.0436,  0.1064,  ...,  0.3563,  0.0737,  0.0103],
        #                                 [ 0.1208,  0.0142,  0.0888,  ..., -0.0901, -0.0133, -0.0015],
        #                                 ...,
        #                                 [ 0.1256,  0.0999,  0.0869,  ...,  0.0000,  0.0000,  0.0000],
        #                                 [ 0.1192,  0.0688,  0.0735,  ...,  0.0000,  0.0000,  0.0000]]), # torch.Size([16, 918])
        #     'item_int_feats': tensor([[  146,   317,  2158,  ...,   0,     0,     0],
        #                               [    8,   431,   927,  ...,   0,     0,     0],
        #                               ...,
        #                               [   90,   242,   261,  ...,   8,     9,   474],
        #                               [  279,   752,  1593,  ...,   0,     0,     0]]), # torch.Size([16, 33])
        #     'item_dense_feats': tensor([], size=(16, 0)), 
        #     'label': tensor([0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0]),  # torch.Size([16])
        #     'timestamp': tensor([1772725036, 1772725277, ..., 1772725162, 1772725530]),  # torch.Size([16])
        #     'seq_a': tensor([[[     0,      0,      0,  ...,      0,      0,      0],
        #                       ...,
        #                       [     1,      1,     16,  ...,      1,      1,     14]],
        #                      [[     0,      0,      0,  ...,      0,      0,      0],
        #                       ...,
        #                       [    12,     16,     16,  ...,      1,     14,      1]],
        #                      ...,
        #                      [[     0,      0,      0,  ...,      0,      0,      0],
        #                       ...,
        #                       [     2,     14,      2,  ...,      0,      0,      0]],
        #                      [[     0,      0,      0,  ...,      0,      0,      0],
        #                       ...,
        #                       [    12,      0,      0,  ...,      0,      0,      0]]]),  # torch.Size([16, 8, 256])
        #     'seq_a_len': tensor([256, 256, 256, ...,  256,  169,  58]),  # torch.Size([16])
        #     'seq_a_time_bucket': tensor([[33, 34, 34,  ..., 58, 58, 58],
        #                                  [34, 42, 42,  ..., 56, 56, 56],
        #                                  ...,
        #                                  [47, 47, 47,  ...,  0,  0,  0],
        #                                  [54, 54, 54,  ...,  0,  0,  0]]), # torch.Size([16, 256])
        #     'seq_b': tensor([[[       6,       14,        3,  ...,        6,       25,        6],
        #                       ...,
        #                       [       0,        0,        0,  ...,   185332,        0,      370]],
        #                      [[       6,       25,       25,  ...,       19,       19,       19],
        #                       ...,
        #                       [       0,        0,        0,  ...,        0,   181624,   181624]],
        #                      ...,
        #                      [[      25,        6,        6,  ...,        0,        0,        0],
        #                       ...,
        #                       [       0,   141137,    53066,  ...,        0,        0,        0]],
        #                      [[      22,       22,       20,  ...,        0,        0,        0],
        #                       ...,
        #                       [       0,        0,        0,  ...,        0,        0,        0]]]), # torch.Size([16, 13, 256])
        #     'seq_b_len': tensor([256, 256, 256, ..., 256,  118,  42]),  # torch.Size([16])
        #     'seq_b_time_bucket': tensor([[24, 34, 34,  ..., 54, 54, 54],
        #                                  [48, 48, 49,  ..., 61, 61, 61],
        #                                  ...,
        #                                  [47, 49, 49,  ...,  0,  0,  0],
        #                                  [56, 56, 61,  ...,  0,  0,  0]]), # torch.Size([16, 256])
        #     'seq_c': tensor([[[      10,       31,       36,  ...,       36,       10,       31],
        #                       ...,
        #                       [       0,        0, 44341152,  ...,        0, 83219569, 83219569]],
        #                      [[      31,       31,       31,  ...,        0,        0,        0],
        #                       ...,
        #                       [79110698, 54451658,        0,  ...,        0,        0,        0]],
        #                      ...,
        #                      [[      31,       31,       31,  ...,        0,        0,        0],
        #                       ...,
        #                       [49695077, 49695077,        0,  ...,        0,        0,        0]],
        #                      [[      42,       31,       31,  ...,        0,        0,        0],
        #                       ...,
        #                       [47959838, 47959838, 47959838,  ...,        0,        0,        0]]]),  # torch.Size([16, 11, 512])
        #     'seq_c_len': tensor([512, 266, 512, ..., 379, 266, 445]), # torch.Size([16])
        #     'seq_c_time_bucket': tensor([[42, 42, 49,  ..., 63, 63, 63],
        #                                  [54, 54, 54,  ...,  0,  0,  0],
        #                                  ...,
        #                                  [47, 47, 47,  ...,  0,  0,  0],
        #                                  [49, 50, 50,  ...,  0,  0,  0]]), # torch.Size([16, 512])
        #     'seq_d': tensor([[[     3,      3,      3,  ...,      0,      0,      0],
        #                       ...,
        #                       [     2,      2,      2,  ...,      0,      0,      0]],
        #                      [[     3,      3,      3,  ...,      3,      3,      3],
        #                       ...,
        #                       [     2,     13,     14,  ...,      2,     14,      2]],
        #                      ...,
        #                      [[     3,      3,      3,  ...,      3,      3,      3],
        #                       ...,
        #                       [    12,      2,     14,  ...,     10,     10,     13]],
        #                      [[     3,      3,      3,  ...,      3,      3,      3],
        #                       ...,
        #                       [     8,     13,     12,  ...,      2,      2,      2]]]), # torch.Size([16, 9, 512])
        #     'seq_d_len': tensor([322, 512, 512, ..., 512, 512, 512]), # torch.Size([16])
        #     'seq_d_time_bucket': tensor([[48, 48, 48,  ...,  0,  0,  0],
        #                                  [35, 37, 37,  ..., 52, 52, 52],
        #                                  ...,
        #                                  [47, 47, 47,  ..., 54, 54, 54],
        #                                  [13, 16, 16,  ..., 53, 53, 53]]), # torch.Size([16, 512])
        #     'user_id': [3864676, 8507274, 11951382, ..., 10685860, 9976196, 8037367],  # 长为 16 的列表
        #     '_seq_domains': ['seq_a', 'seq_b', 'seq_c', 'seq_d']
        # }

        # 'label',  'timestamp',  'user_id', '_seq_domains' 未加入 ModelInput 中！
        model_input = self._make_model_input(device_batch)
        # ModelInput(
        #     user_int_feats=tensor([[  2, 674, 280,  ...,   2,   0,   0],
        #                         [  4, 645, 630,  ...,   1,   0,   0],
        #                         ...,
        #                         [  4, 198, 944,  ...,   0,   0,   0],
        #                         [  4, 325, 134,  ...,   0,   6,   0]]), # torch.Size([16, 411])
        #     item_int_feats=tensor([[  146,   317,  2158,  ...,   0,     0,     0],
        #                         [    8,   431,   927,  ...,   0,     0,     0],
        #                         ...,
        #                         [   90,   242,   261,  ...,   8,     9,   474],
        #                         [  279,   752,  1593,  ...,   0,     0,     0]]), # torch.Size([16, 33])
        #     user_dense_feats=tensor([[ 0.1255,  0.0436,  0.1064,  ...,  0.3563,  0.0737,  0.0103],
        #                         [ 0.1208,  0.0142,  0.0888,  ..., -0.0901, -0.0133, -0.0015],
        #                         ...,
        #                         [ 0.1256,  0.0999,  0.0869,  ...,  0.0000,  0.0000,  0.0000],
        #                         [ 0.1192,  0.0688,  0.0735,  ...,  0.0000,  0.0000,  0.0000]]), # torch.Size([16, 918])
        #     item_dense_feats=tensor([], size=(16, 0)), 
        #     seq_data={
        #         'seq_a': tensor([[[     0,      0,      0,  ...,      0,      0,      0],
        #                           ...,
        #                           [     1,      1,     16,  ...,      1,      1,     14]],
        #                          [[     0,      0,      0,  ...,      0,      0,      0],
        #                           ...,
        #                           [    12,     16,     16,  ...,      1,     14,      1]],
        #                          ...,
        #                          [[     0,      0,      0,  ...,      0,      0,      0],
        #                           ...,
        #                           [     2,     14,      2,  ...,      0,      0,      0]],
        #                          [[     0,      0,      0,  ...,      0,      0,      0],
        #                           ...,
        #                           [    12,      0,      0,  ...,      0,      0,      0]]]),  # torch.Size([16, 8, 256])
        #         'seq_b': tensor([[[       6,       14,        3,  ...,        6,       25,        6],
        #                           ...,
        #                           [       0,        0,        0,  ...,   185332,        0,      370]],
        #                          [[       6,       25,       25,  ...,       19,       19,       19],
        #                           ...,
        #                           [       0,        0,        0,  ...,        0,   181624,   181624]],
        #                          ...,
        #                          [[      25,        6,        6,  ...,        0,        0,        0],
        #                           ...,
        #                           [       0,   141137,    53066,  ...,        0,        0,        0]],
        #                          [[      22,       22,       20,  ...,        0,        0,        0],
        #                           ...,
        #                           [       0,        0,        0,  ...,        0,        0,        0]]]), # torch.Size([16, 13, 256])
        #         'seq_c': tensor([[[      10,       31,       36,  ...,       36,       10,       31],
        #                           ...,
        #                           [       0,        0, 44341152,  ...,        0, 83219569, 83219569]],
        #                          [[      31,       31,       31,  ...,        0,        0,        0],
        #                           ...,
        #                           [79110698, 54451658,        0,  ...,        0,        0,        0]],
        #                          ...,
        #                          [[      31,       31,       31,  ...,        0,        0,        0],
        #                           ...,
        #                           [49695077, 49695077,        0,  ...,        0,        0,        0]],
        #                          [[      42,       31,       31,  ...,        0,        0,        0],
        #                           ...,
        #                           [47959838, 47959838, 47959838,  ...,        0,        0,        0]]]),  # torch.Size([16, 11, 512])
        #         'seq_d': tensor([[[     3,      3,      3,  ...,      0,      0,      0],
        #                           ...,
        #                           [     2,      2,      2,  ...,      0,      0,      0]],
        #                          [[     3,      3,      3,  ...,      3,      3,      3],
        #                           ...,
        #                           [     2,     13,     14,  ...,      2,     14,      2]],
        #                          ...,
        #                          [[     3,      3,      3,  ...,      3,      3,      3],
        #                           ...,
        #                           [    12,      2,     14,  ...,     10,     10,     13]],
        #                          [[     3,      3,      3,  ...,      3,      3,      3],
        #                           ...,
        #                           [     8,     13,     12,  ...,      2,      2,      2]]]), # torch.Size([16, 9, 512])
        #     },
        #     seq_lens={
        #         'seq_a': tensor([256, 256, 256, ...,  256,  169,  58]),  # torch.Size([16])
        #         'seq_b': tensor([256, 256, 256, ..., 256,  118,  42]),  # torch.Size([16])
        #         'seq_c': tensor([512, 266, 512, ..., 379, 266, 445]), # torch.Size([16])
        #         'seq_d': tensor([322, 512, 512, ..., 512, 512, 512]), # torch.Size([16])
        #     }, 
        #     seq_time_buckets={
        #         'seq_a': tensor([[33, 34, 34,  ..., 58, 58, 58],
        #                                         [34, 42, 42,  ..., 56, 56, 56],
        #                                         ...,
        #                                         [47, 47, 47,  ...,  0,  0,  0],
        #                                         [54, 54, 54,  ...,  0,  0,  0]]), # torch.Size([16, 256])
        #         'seq_b': tensor([[24, 34, 34,  ..., 54, 54, 54],
        #                                         [48, 48, 49,  ..., 61, 61, 61],
        #                                         ...,
        #                                         [47, 49, 49,  ...,  0,  0,  0],
        #                                         [56, 56, 61,  ...,  0,  0,  0]]), # torch.Size([16, 256])
        #         'seq_c': tensor([[42, 42, 49,  ..., 63, 63, 63],
        #                                         [54, 54, 54,  ...,  0,  0,  0],
        #                                         ...,
        #                                         [47, 47, 47,  ...,  0,  0,  0],
        #                                         [49, 50, 50,  ...,  0,  0,  0]]), # torch.Size([16, 512])
        #         'seq_d': tensor([[48, 48, 48,  ...,  0,  0,  0],
        #                                         [35, 37, 37,  ..., 52, 52, 52],
        #                                         ...,
        #                                         [47, 47, 47,  ..., 54, 54, 54],
        #                                         [13, 16, 16,  ..., 53, 53, 53]]), # torch.Size([16, 512])
        #     }
        # )
        with autocast_ctx:
            logits = self.model(model_input)  # (B, 1) # torch.Size([16, 1])
            logits = logits.squeeze(-1)  # (B,) # torch.Size([16])

            # logits: torch.Size([16])
            # tensor([-0.3345,  0.2717, -0.1480,  ..., -0.0271,  0.3414,  0.1054], grad_fn=<SqueezeBackward1>)

            # label: torch.Size([16])
            # tensor([0., 0., 0., 0., 0., 0., 1., 0., 0., 0., 0., 0., 0., 0., 1., 0.])
            if self.label_smooth > 0: # 0.05
                epsilon_2 = self.label_smooth * 2 # 0.1
                smoothed_label = label.clone() # 避免 in-place 修改
                # 正样本 (1) → 1 - ε
                # 负样本 (0) → ε
                smoothed_label = smoothed_label * (1 - epsilon_2) + epsilon_2 / 2.0 #  torch.Size([16])
                # tensor([0.0500, 0.0500, 0.0500, 0.0500, 0.0500, 0.0500, 0.9500, 0.0500, 0.0500, 0.0500, 0.0500, 0.0500, 0.0500, 0.0500, 0.9500, 0.0500])
                target = smoothed_label
            else:
                target = label
            if self.loss_type == 'focal':
                loss = sigmoid_focal_loss(logits, target, alpha=self.focal_alpha, gamma=self.focal_gamma)
            else:
                loss = F.binary_cross_entropy_with_logits(logits, target) # tensor(0.1577, grad_fn=<MeanBackward0>)
            pointwise_loss = loss
            # pairwise loss (only when weight > 0)
            pairwise_loss_item = 0.0
            if self.pairwise_loss_weight > 0:
                pos_mask = label == 1
                neg_mask = ~pos_mask
                if pos_mask.any() and neg_mask.any():
                    pos_logits = logits[pos_mask]       # (n_pos,)
                    neg_logits = logits[neg_mask]       # (n_neg,)
                    # Pairwise diff: (n_pos, n_neg)
                    diff = pos_logits.unsqueeze(1) - neg_logits.unsqueeze(0)
                    pairwise_loss = -F.logsigmoid(diff).mean()
                    pairwise_loss_item = pairwise_loss.item()
                    loss = loss + self.pairwise_loss_weight * pairwise_loss

        # FP16 needs scaled backward; BF16 does not
        if self._grad_scaler is not None:
            self._grad_scaler.scale(loss).backward()
        else:
            loss.backward()

        if self._grad_scaler is not None:
            self._grad_scaler.unscale_(self.dense_optimizer)
            if self.sparse_optimizer is not None:
                self._grad_scaler.unscale_(self.sparse_optimizer)
        # foreach=False: avoids a PyTorch _foreach_norm CUDA kernel bug observed
        # with certain tensor shapes in this project.
        grad_norm_before = torch.nn.utils.clip_grad_norm_( # ! # 5.397327205176909
            self.model.parameters(),
            max_norm=1.0,
            foreach=False,
        )
        grad_norm_after = min(grad_norm_before, 1.0)  # ! # 0.9999997783878847

        p = torch.sigmoid(logits) # ! # torch.Size([16])
        # tensor([0.4171, 0.5675, 0.4631, 0.6364, 0.4383, 0.4118, 0.4335, 0.5377, 0.5592,  0.4358, 0.6354, 0.4788, 0.4675, 0.4932, 0.5845, 0.5263],  grad_fn=<SigmoidBackward0>)
        pos_p = p[device_batch['label'].bool()] # ！
        # tensor([0.4335, 0.5845], grad_fn=<IndexBackward0>)
        neg_p = p[~(device_batch['label'].bool())] # ！
        # tensor([0.4171, 0.5675, 0.4631, 0.6364, 0.4383, 0.4118, 0.5377, 0.5592, 0.4358, 0.6354, 0.4788, 0.4675, 0.4932, 0.5263], grad_fn=<IndexBackward0>)
        mean_pos_p = pos_p.mean().item() # ! # 0.5089883208274841
        mean_neg_p = neg_p.mean().item() # ! # 0.5048762559890747
        current_dense_lr = self.dense_optimizer.param_groups[0]['lr'] # ! # 0.0001 
        current_sparse_lr = self.sparse_optimizer.param_groups[0]['lr'] # ! # 0.05

        if self._grad_scaler is not None:
            self._grad_scaler.step(self.dense_optimizer)
            if self.sparse_optimizer is not None:
                self._grad_scaler.step(self.sparse_optimizer)
            self._grad_scaler.update()
        else:
            self.dense_optimizer.step()
            if self.sparse_optimizer is not None:
                self.sparse_optimizer.step()
        
        return loss.item(), mean_pos_p, mean_neg_p, grad_norm_before, grad_norm_after, current_dense_lr, current_sparse_lr, pointwise_loss.item(), pairwise_loss_item # ! # 0.1576574295759201, 0.5089883208274841, 0.5048762559890747, 5.397327205176909, 0.9999997783878847

    def evaluate(self, epoch: Optional[int] = None) -> Tuple[float, float]:
        """Run validation over ``self.valid_loader`` and return ``(AUC, logloss)``.

        NaN predictions (which can arise from exploding gradients) are filtered
        out before computing both metrics.
        """
        print("Start Evaluation (PCVRHyFormer) - validation")
        self.model.eval()
        if not epoch:
            epoch = -1

        pbar = tqdm(enumerate(self.valid_loader), total=len(self.valid_loader)) # total = 63

        all_logits_list = []
        all_labels_list = []

        with torch.no_grad():
            for step, batch in pbar:
                logits, labels = self._evaluate_step(batch)
                all_logits_list.append(logits.detach().cpu())
                all_labels_list.append(labels.detach().cpu())

        all_logits = torch.cat(all_logits_list, dim=0)
        all_labels = torch.cat(all_labels_list, dim=0).long()

        # Binary AUC via sklearn.
        probs = torch.sigmoid(all_logits).numpy()
        labels_np = all_labels.numpy()

        # Filter NaN predictions (may appear if gradients explode).
        nan_mask = np.isnan(probs)
        if nan_mask.any():
            n_nan = int(nan_mask.sum())
            logging.warning(f"[Evaluate] {n_nan}/{len(probs)} predictions are NaN, filtering them out")
            valid_mask = ~nan_mask
            probs = probs[valid_mask]
            labels_np = labels_np[valid_mask]

        if len(probs) == 0 or len(np.unique(labels_np)) < 2:
            auc = 0.0
        else:
            auc = float(roc_auc_score(labels_np, probs))

        # Binary logloss (same NaN filtering).
        valid_logits = all_logits[~torch.isnan(all_logits)]
        valid_labels = all_labels[~torch.isnan(all_logits)]
        if len(valid_logits) > 0:
            logloss = F.binary_cross_entropy_with_logits(valid_logits, valid_labels.float()).item()
        else:
            logloss = float('inf')

        return auc, logloss

    def _evaluate_step(
        self, batch: Dict[str, Any]
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Run a single validation step and return ``(logits, labels)``."""
        device_batch = self._batch_to_device(batch)
        label = device_batch['label'] # tensor([0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0]) # torch.Size([16])

        model_input = self._make_model_input(device_batch)
        # model_input: 
        # ModelInput(user_int_feats=tensor([[   4,    0,    6,  ...,    1,    0,    0],
        #                                   [   4, 1137,  601,  ...,    1,    6,    0],
        #                                   ...,
        #                                   [   4,  645,  630,  ...,    1,    0,    0],
        #                                   [   4, 1586,  653,  ...,    1,    2,    0]]),  # torch.Size([16, 411])
        #            item_int_feats=tensor([[  161, 893,    0,  ...,    0,    0,    0],
        #                                   [   90, 518,  455,  ...,   29,   134, 873],
        #                                   ...,
        #                                   [    8, 431,  927,  ...,    0,    0,    0],
        #                                   [   23, 669, 1303,  ...,    0,    0,    0]]), # torch.Size([16, 33])
        #            user_dense_feats=tensor([[ 1.0862e-01, -2.0586e-02,  9.2901e-02,  ..., -1.2180e-01, -1.7900e-02, -2.5000e-03],
        #                                     [ 1.1631e-01,  7.9820e-02,  9.9188e-02,  ...,  0.0000e+00,  0.0000e+00,  0.0000e+00],
        #                                     ...,
        #                                     [ 1.2082e-01,  1.4171e-02,  8.8848e-02,  ..., -9.0100e-02, -1.3300e-02, -1.5000e-03],
        #                                     [ 7.1662e-02,  5.1777e-02,  8.8747e-02,  ...,  3.1310e-01,  4.6100e-02,  4.7000e-03]]), # torch.Size([16, 918])
        #            item_dense_feats=tensor([], size=(16, 0)), 
        #            seq_data={
        #                 'seq_a': tensor([[[     0,      0,      0,  ...,      0,      0,      0],
        #                                   ...,
        #                                   [    12,      1,      0,  ...,     14,      0,      0]],
        #                                  [[     0,      0,      0,  ...,      0,      0,      0],
        #                                   ...,
        #                                   [    14,      1,      1,  ...,     16,     16,      1]],
        #                                  ...,
        #                                  [[     0,      0,      0,  ...,      0,      0,      0],
        #                                   ...,
        #                                   [    12,     16,     16,  ...,      1,     14,      1]],
        #                                  [[     0,      0,      0,  ...,      0,      0, 196425],
        #                                   ...,
        #                                   [     1,      1,     17,  ...,     16,     16,     17]]]), # torch.Size([16, 8, 256])
        #                 'seq_b': tensor([[[     6,     22,      6,  ...,     22,     22,     22],
        #                                   ...,
        #                                   [     0,      0,      0,  ...,        0,        0,        0]],
        #                                  [[    25,     25,     25,  ...,       24,       24,        8],
        #                                   ...,
        #                                   [     0,      0,      0,  ...,        0,        0,    70448]],
        #                                  ...,
        #                                  [[     6,     25,     25,  ...,       19,       19,       19],
        #                                   ...,
        #                                   [     0,      0,      0,  ...,        0,   181624,   181624]],
        #                                  [[     5,      5,      1,  ...,        6,        6,        6],
        #                                   ...,
        #                                   [    7547, 7547,      0,  ...,   117766,     1990,    72260]]]), # torch.Size([16, 13, 256])
        #                 'seq_c': tensor([[[      31,       31,       31,  ...,        0,        0,        0],
        #                                   ...,
        #                                   [       0, 80211853,        0,  ...,        0,        0,        0]],
        #                                  [[      31,       31,       31,  ...,        0,        0,        0],
        #                                   ...,
        #                                   [41727892, 82135815, 44760703,  ...,        0,        0,        0]],
        #                                   ...,
        #                                  [[      31,       31,       31,  ...,        0,        0,        0],
        #                                   ...,
        #                                   [79110698, 54451658,        0,  ...,        0,        0,        0]],
        #                                  [[      31,       14,       31,  ...,        0,        0,        0],
        #                                   ...,
        #                                   [14547649,        0,        0,  ...,        0,        0,        0]]]), # torch.Size([16, 11, 512])
        #                 'seq_d': tensor([[[     3,      3,      3,  ...,      3,      3,      3],
        #                                   ...,
        #                                   [     2,      2,      2,  ...,      2,      2,      2]],
        #                                  [[     0,      0,      0,  ...,      0,      0,      0],
        #                                   ...,
        #                                   [     0,      0,      0,  ...,      0,      0,      0]],
        #                                  ...,
        #                                  [[     3,      3,      3,  ...,      3,      3,      3],
        #                                   ...,
        #                                   [     2,     13,     14,  ...,      2,     14,      2]],
        #                                  [[     3,      3,      3,  ...,      3,      3,      3],
        #                                   ...,
        #                                   [    14,      2,      2,  ...,      8,     12,      8]]]) # torch.Size([16, 9, 512])
        #            }, 
        #            seq_lens={
        #                 'seq_a': tensor([256, 256, 203, ..., 256, 256, 256]), # torch.Size([16])
        #                 'seq_b': tensor([256, 256, 250, ..., 256, 256, 256]), # torch.Size([16])
        #                 'seq_c': tensor([333, 303, 512, ..., 365, 266, 393]), # torch.Size([16])
        #                 'seq_d': tensor([512,   0, 297, ..., 512, 512, 512])  # torch.Size([16])
        #            }, 
        #            seq_time_buckets={
        #                 'seq_a': tensor([[42, 48, 48,  ..., 61, 61, 61], 
        #                                  ...,
        #                                  [22, 22, 22,  ..., 57, 57, 57]]), # torch.Size([16, 256])
        #                 'seq_b': tensor([[32, 40, 42,  ..., 57, 57, 57],
        #                                  ...,
        #                                  [16, 16, 22,  ..., 55, 55, 55]]), # torch.Size([16, 256])
        #                 'seq_c': tensor([[48, 51, 52,  ...,  0,  0,  0],
        #                                  ...,
        #                                  [21, 24, 44,  ...,  0,  0,  0]]), # torch.Size([16, 512])
        #                 'seq_d': tensor([[24, 32, 32,  ..., 54, 54, 54],
        #                                  ...,
        #                                  [14, 22, 24,  ..., 54, 54, 54]])  # torch.Size([16, 512])
        #            }
        # )
        with torch.autocast(device_type='cuda', dtype=self._amp_torch_dtype, enabled=self._amp_enabled):
            logits, _ = self.model.predict(model_input)  # (B, 1), (B, D)
        logits = logits.squeeze(-1)  # (B,)

        return logits, label
