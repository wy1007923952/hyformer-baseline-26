SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
export PYTHONPATH="${SCRIPT_DIR}:${PYTHONPATH}"

# ---- Active config: RankMixer NS tokenizer (no ns_groups.json required) ----

python3 -u "${SCRIPT_DIR}/train.py" \
    --batch_size 256 \
    --lr 1e-4 \
    --num_epochs 999 \
    --patience 5 \
    --seed 42 \
    --buffer_batches 20 \
    --train_ratio 1.0 \
    --valid_ratio 0.1 \
    --seq_max_lens seq_a:256,seq_b:256,seq_c:512,seq_d:512 \
    --d_model 64 \
    --emb_dim 64 \
    --num_hyformer_blocks 2 \
    --num_heads 4 \
    --seq_encoder_type transformer \
    --hidden_mult 4 \
    --dropout_rate 0.01 \
    --seq_top_k 50 \
    --action_num 1 \
    --use_time_buckets \
    --rank_mixer_mode full \
    --rope_base 10000.0 \
    --loss_type bce \
    --focal_alpha 0.1 \
    --focal_gamma 2.0 \
    --sparse_lr 0.05 \
    --sparse_weight_decay 0.0 \
    --reinit_sparse_after_epoch 1 \
    --reinit_cardinality_threshold 0 \
    --seq_id_threshold 10000 \
    --label_smooth 0.0 \
    --further_deterministic \
    --pairwise_loss_weight 0.1 \
    --ns_tokenizer_type rankmixer \
    --user_ns_tokens 5 \
    --item_ns_tokens 2 \
    --num_queries 2 \
    --ns_groups_json "" \
    --emb_skip_threshold 1000000 \
    --num_workers 8 \
    "$@"

# --scale_dense \
# --amp_type bf16 \
# --pairwise_loss_weight 0.1 \

# 原始Baseline完整参数：
# python3 -u "${SCRIPT_DIR}/train.py" \
#     --batch_size 256 \
#     --lr 1e-4 \
#     --num_epochs 999 \
#     --patience 5 \
#     --seed 42 \
#     --buffer_batches 20 \
#     --train_ratio 1.0 \
#     --valid_ratio 0.1 \
#     --seq_max_lens seq_a:256,seq_b:256,seq_c:512,seq_d:512 \
#     --d_model 64 \
#     --emb_dim 64 \
#     --num_hyformer_blocks 2 \
#     --num_heads 4 \
#     --seq_encoder_type transformer \ // choices=['swiglu', 'transformer', 'longer']
#     --hidden_mult 4 \
#     --dropout_rate 0.01 \ // Backbone 的 Dropout 率（序列 ID Embedding 的 dropout 是该值的两倍）
#     --seq_top_k 50 \ // LongerEncoder 保留的最近 Token 数量，only effective when --seq_encoder_type=longer
#     # --seq_causal \ // LongerEncoder 自注意力机制是否采用因果掩码，only effective when --seq_encoder_type=longer
#     --action_num 1 \ // 1 = single binary-classification logit; >1 = multi-label
#     --use_time_buckets \
#     # --no_time_buckets \
#     --rank_mixer_mode full \ // choices=['full', 'ffn_only', 'none']
#     # --use_rope \
#     --rope_base 10000.0 \
#     --loss_type bce \ // choices=['bce', 'focal']
#     --focal_alpha 0.1 \ // effective only when --loss_type=focal
#     --focal_gamma 2.0 \ // effective only when --loss_type=focal
#     --sparse_lr 0.05 \
#     --sparse_weight_decay 0.0 \
#     --reinit_sparse_after_epoch 1 \ // 从第 N 个 epoch 开始，在每个 epoch 结束时，对 vocab_size 大于 --reinit_cardinality_threshold 的 Embedding 进行重新初始化，并重建 Adagrad 优化器的状态 （针对高基数特征的 cold-restart 技巧，用于减少过拟合）
#     --reinit_cardinality_threshold 0 \ // 重初始化策略使用的基数阈值：vocab_size 超过该阈值的 Embedding 将在每个 epoch 结束时被重置 （0 = 不对任何 Embedding 进行重置）
#     --seq_id_threshold 10000 \ // 在序列 Tokenizer 中，vocab_size 超过该阈值的特征将被视为 ID 特征，在训练时会额外施加 dropout(rate*2) 以减少过拟合。vocab_size 低于或等于该阈值的特征将被视为侧信息（side-info），不施加额外的 dropout
#     # 以下是baseline的初始参数
#     --ns_tokenizer_type rankmixer \ // choices=['group', 'rankmixer']
#     --user_ns_tokens 5 \
#     --item_ns_tokens 2 \
#     --num_queries 2 \
#     --ns_groups_json "" \
#     --emb_skip_threshold 1000000 \ // 在模型构建阶段，对于 vocab_size 超过该阈值的特征，将不为其创建 Embedding，在前向传播时直接用零向量表示（0 = 不跳过任何特征；所有特征都获得 Embedding）。适用于超高基数特征的 GPU 内存节省场景
#     --num_workers 8 \
#     "$@"

# Sequence encoder variant: 
#     swiglu = 不带注意力机制的 SwiGLU
#     transformer = 标准自注意力机制
#     longer = Top-K 压缩编码器（仅该变体使用 --seq_top_k / --seq_causal 参数）


# RankMixerBlock mode: 
#     full = token mixing + per-token FFN（要求 d_model 能被 T 整除）
#     ffn_only = per-token FFN only
#     none = 恒等映射（Identity Passthrough）

# NS tokenizer variant: 
# group = 将每个 group 投影为一个 Token 
# rankmixer = 将所有 Embedding 拼接后切分成等大小的 chunk（Token 数量可调）



# ---- Alternative config: GroupNSTokenizer driven by ns_groups.json ----
# Uses feature grouping from ns_groups.json (7 user groups + 4 item groups).
# With d_model=64 and num_ns=12 (7 user_int + 1 user_dense + 4 item_int),
# only num_queries=1 satisfies d_model % T == 0 (T = num_queries*4 + num_ns).
# To switch, comment out the block above and uncomment the block below.
#
# python3 -u "${SCRIPT_DIR}/train.py" \
#     --ns_tokenizer_type group \
#     --ns_groups_json "${SCRIPT_DIR}/ns_groups.json" \
#     --num_queries 1 \
#     --emb_skip_threshold 1000000 \
#     --num_workers 8 \
#     "$@"


