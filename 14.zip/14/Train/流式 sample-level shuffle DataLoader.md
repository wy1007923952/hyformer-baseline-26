你这段代码其实已经是一个完整的：

# 流式 sample-level shuffle DataLoader

整体逻辑可以概括成：

```text id="4bjk9d"
不断读取 batch
→ 暂存到 buffer
→ 拼接成大 tensor
→ 全局随机打乱
→ 再重新切 batch
→ yield 给训练
```

下面按“真实运行流程”完整拆开。

---

# 第一部分：主循环

这里：

```python id="wyqjlwm"
if self.shuffle and self.buffer_batches > 1:
```

表示：

只有：

* 开启 shuffle
* buffer_batches > 1

才使用 buffered shuffle。

否则：

```python id="y5eu5f"
yield batch_dict
```

直接输出。

---

# Step 1：先缓存 batch

```python id="vj8t0n"
buffer.append(batch_dict)
```

假设：

```python id="9wl18s"
batch_size = 256
buffer_batches = 20
```

那么：

buffer 会慢慢变成：

```text id="waj0qt"
[
  batch1,
  batch2,
  ...
  batch20
]
```

每个 batch：

```text id="d1x9d9"
256 samples
```

总共：

```text id="3c8vsf"
5120 samples
```

---

# Step 2：缓存满了才 shuffle

```python id="18z6ow"
if len(buffer) >= self.buffer_batches:
```

达到：

```text id="o9ztn5"
20 batches
```

后：

开始真正 shuffle。

---

# Step 3：flush buffer

这里：

```python id="pw4u97"
yield from self._flush_buffer(buffer)
```

等价于：

```python id="1l8r77"
for x in self._flush_buffer(buffer):
    yield x
```

意思：

```text id="n0yz6j"
_flush_buffer 是一个 generator
它会不断产生新的 batch
```

然后：

主 dataloader 把这些 batch 一个个输出。

---

# 第二部分：_flush_buffer()

核心逻辑都在这里。

---

# Step 4：把所有 batch 拼接

这里：

```python id="3m4l8y"
merged[k] = torch.cat([b[k] for b in buffer], dim=0)
```

假设：

原来：

```text id="cwsq3u"
batch1:
label = [a1 a2 a3]

batch2:
label = [b1 b2 b3]
```

concat 后：

```text id="kzeyii"
[a1 a2 a3 b1 b2 b3]
```

shape：

```text id="xq95ru"
[buffer_batches * batch_size]
```

例如：

```text id="tl9jnp"
[5120]
```

---

# 注意

这里是：

# 所有 tensor feature 一起 concat

例如：

```text id="w8x1m7"
user_id
item_id
seqs
dense feats
labels
...
```

全部拼接。

---

# Step 5：生成随机排列

这里：

```python id="6f0d4l"
rand_idx = torch.randperm(total_rows)
```

例如：

```text id="ffwg0k"
[7 1 3 0 5 8 2 6 4]
```

表示：

```text id="6xohzy"
把所有 sample 完全随机重排
```

这是：

# sample-level shuffle

不是 batch-level。

---

# Step 6：重新切 batch

这里：

```python id="9e6wzc"
for i in range(0, total_rows, self.batch_size):
```

例如：

```text id="4z7l57"
0
256
512
768
...
```

每次取：

```python id="mb1ha0"
v[rand_idx[i:end]]
```

得到：

```text id="ygtm0x"
新的随机 batch
```

例如：

原来：

```text id="1lgnyl"
batch1:
[userA userA userA]

batch2:
[userB userB userB]
```

shuffle 后：

```text id="4f0gzj"
new_batch:
[userA userB userA userC ...]
```

更随机。

训练更稳定。

---

# Step 7：yield 新 batch

```python id="s4qj9f"
yield batch
```

开始送给 trainer。

---

# Step 8：清理内存

最后：

```python id="hn5agx"
del merged
buffer.clear()
```

避免：

```text id="mkpg3q"
大 tensor 长期驻留
```

否则：

CPU RAM 会持续增长。

---

# 最后这个：

```python id="nncxlu"
if buffer:
    yield from self._flush_buffer(buffer)
```

处理：

# 不足 buffer_batches 的尾巴数据

例如：

总共有：

```text id="hmp75t"
53 batches
```

前：

```text id="r7lk8r"
20 + 20
```

flush 两次。

最后：

```text id="mr8kll"
剩 13 个 batch
```

也要输出。

所以最后再 flush 一次。

---

# 这个实现本质上是：

# Streaming Approximate Global Shuffle

即：

```text id="jlwmzx"
流式近似全局随机打乱
```

工业推荐非常经典。

---

# 它比简单 shuffle(batch) 好很多

因为：

普通：

```python id="jlwmzx2"
random.shuffle(buffer)
```

只是：

```text id="jlwmzx3"
batch 顺序随机
```

但：

batch 内部不随机。

---

# 你的实现是：

```text id="jlwmzx4"
sample 级随机
```

效果接近：

```python id="jlwmzx5"
真正全局 shuffle
```

---

# 但它有个代价

这里：

```python id="jlwmzx6"
torch.cat(...)
```

很重。

尤其你这个任务：

```text id="jlwmzx7"
45 sequence features
```

并且：

```text id="jlwmzx8"
seq len 512
```

会导致：

# DataLoader CPU 内存非常大

例如：

```text id="jlwmzx9"
5120 × 512 × 45
```

非常恐怖。

---

# 你现在其实很危险

因为你当前配置：

```text id="jlwmzx10"
batch_size = 256
buffer_batches = 20
seq_c = 512
seq_d = 512
```

意味着：

```text id="jlwmzx11"
一次 flush：
5120 samples
```

并且：

sequence tensor 巨大。

---

# 这会导致

## 1. DataLoader worker RAM 爆炸

尤其：

```python id="jlwmzx12"
num_workers = 16
```

16 个 worker：

每个都可能：

```text id="jlwmzx13"
缓存 5120 samples
```

CPU 内存会非常离谱。

---

# 2. torch.cat 巨慢

因为：

```text id="jlwmzx14"
会产生大 tensor copy
```

---

# 3. worker 卡死

工业里非常常见：

```text id="jlwmzx15"
GPU utilization 0%
CPU 100%
```

实际上卡在：

```python id="jlwmzx16"
torch.cat
```

---

# 一句话总结


# 「有限内存条件下的 sample-level streaming shuffle」

流程：

```text id="jlwmzx20"
batch stream
→ buffer
→ concat
→ sample shuffle
→ re-batch
→ yield
```

这是工业推荐系统里非常经典的：

```text id="jlwmzx21"
IterableDataset shuffle 实现
```

因为真正全局 shuffle 在 TB 级 parquet 上根本做不到。
